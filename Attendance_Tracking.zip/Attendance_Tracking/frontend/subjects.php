<?php
require_once 'config.php';

// Get all subjects
$subjectsResponse = apiRequest('/subjects');
$subjects = $subjectsResponse['data']['subjects'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Subjects - GPS Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        .subject-map { height: 250px; }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-indigo-600 text-white shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-book text-2xl"></i>
                    <div>
                        <h1 class="text-xl font-bold">Available Subjects</h1>
                        <p class="text-sm text-indigo-200">GPS Attendance System</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="login.php" class="hover:text-indigo-200">
                        <i class="fas fa-sign-in-alt mr-1"></i> Student Login
                    </a>
                    <a href="admin/index.php" class="hover:text-indigo-200">
                        <i class="fas fa-user-shield mr-1"></i> Admin
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <div class="text-center mb-8">
            <h2 class="text-3xl font-bold text-gray-800 mb-2">Browse Available Subjects</h2>
            <p class="text-gray-600">View all subjects and their locations. Login to check in for attendance.</p>
        </div>

        <!-- Subjects Grid -->
        <?php if (empty($subjects)): ?>
            <div class="bg-white rounded-lg shadow-md p-12 text-center">
                <i class="fas fa-book text-6xl text-gray-400 mb-4"></i>
                <h3 class="text-xl font-semibold text-gray-700 mb-2">No Subjects Available</h3>
                <p class="text-gray-600 mb-6">There are currently no subjects configured in the system.</p>
                <a href="admin/subjects.php" class="inline-block bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition">
                    <i class="fas fa-plus mr-2"></i>
                    Add Subject (Admin)
                </a>
            </div>
        <?php else: ?>
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($subjects as $subject): ?>
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition">
                        <!-- Map -->
                        <div id="map-<?= h($subject['subject_id']) ?>" class="subject-map"></div>
                        
                        <!-- Content -->
                        <div class="p-6">
                            <h3 class="text-xl font-bold text-gray-800 mb-3"><?= h($subject['title']) ?></h3>
                            
                            <div class="space-y-2 text-sm text-gray-600 mb-4">
                                <?php if (!empty($subject['instructor'])): ?>
                                    <p class="flex items-center">
                                        <i class="fas fa-chalkboard-teacher mr-2 w-5 text-indigo-600"></i>
                                        <span><?= h($subject['instructor']) ?></span>
                                    </p>
                                <?php endif; ?>
                                
                                <?php if (!empty($subject['location_name'])): ?>
                                    <p class="flex items-center">
                                        <i class="fas fa-map-marker-alt mr-2 w-5 text-indigo-600"></i>
                                        <span><?= h($subject['location_name']) ?></span>
                                    </p>
                                <?php endif; ?>
                                
                                <?php if ($subject['scheduled_start']): ?>
                                    <p class="flex items-center">
                                        <i class="fas fa-clock mr-2 w-5 text-indigo-600"></i>
                                        <span>
                                            <?= date('g:i A', strtotime($subject['scheduled_start'])) ?> - 
                                            <?= date('g:i A', strtotime($subject['scheduled_end'])) ?>
                                        </span>
                                    </p>
                                <?php endif; ?>
                                
                                <p class="flex items-center">
                                    <i class="fas fa-circle-notch mr-2 w-5 text-indigo-600"></i>
                                    <span>Geofence Radius: <?= h($subject['geofence_radius_meters']) ?>m</span>
                                </p>
                            </div>

                            <div class="pt-4 border-t border-gray-200">
                                <a href="login.php" 
                                   class="block w-full text-center bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition font-semibold">
                                    <i class="fas fa-sign-in-alt mr-2"></i>
                                    Login to Check In
                                </a>
                            </div>
                        </div>
                    </div>

                    <script>
                        (function() {
                            const map = L.map('map-<?= h($subject['subject_id']) ?>', {
                                center: [<?= $subject['geofence_center_lat'] ?>, <?= $subject['geofence_center_lng'] ?>],
                                zoom: 16,
                                zoomControl: false,
                                dragging: true,
                                scrollWheelZoom: false
                            });

                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                attribution: '© OpenStreetMap'
                            }).addTo(map);

                            // Add geofence circle
                            L.circle([<?= $subject['geofence_center_lat'] ?>, <?= $subject['geofence_center_lng'] ?>], {
                                radius: <?= $subject['geofence_radius_meters'] ?>,
                                color: '#4f46e5',
                                fillColor: '#818cf8',
                                fillOpacity: 0.2,
                                weight: 2
                            }).addTo(map);

                            // Add marker
                            L.marker([<?= $subject['geofence_center_lat'] ?>, <?= $subject['geofence_center_lng'] ?>])
                                .addTo(map)
                                .bindPopup('<b><?= h($subject['location_name']) ?></b><br><?= h($subject['title']) ?>');
                        })();
                    </script>
                <?php endforeach; ?>
            </div>

            <!-- Info Box -->
            <div class="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 class="font-semibold text-blue-800 mb-3 flex items-center">
                    <i class="fas fa-info-circle mr-2"></i>
                    How It Works
                </h3>
                <div class="grid md:grid-cols-3 gap-4 text-sm text-blue-700">
                    <div>
                        <div class="flex items-center mb-2">
                            <div class="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center mr-2 font-bold">1</div>
                            <span class="font-semibold">Login</span>
                        </div>
                        <p>Use your Student ID to access the system</p>
                    </div>
                    <div>
                        <div class="flex items-center mb-2">
                            <div class="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center mr-2 font-bold">2</div>
                            <span class="font-semibold">Check In</span>
                        </div>
                        <p>Go to the class location and check in when you arrive</p>
                    </div>
                    <div>
                        <div class="flex items-center mb-2">
                            <div class="bg-blue-600 text-white rounded-full w-8 h-8 flex items-center justify-center mr-2 font-bold">3</div>
                            <span class="font-semibold">Stay Within Geofence</span>
                        </div>
                        <p>Remain within the marked area during class time</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="bg-white mt-12 py-6 border-t border-gray-200">
        <div class="container mx-auto px-4 text-center text-gray-600">
            <p class="mb-2">
                <i class="fas fa-map-marker-alt mr-1"></i>
                GPS Attendance Tracking System
            </p>
            <p class="text-sm">
                Real-time location-based attendance with geofence validation
            </p>
        </div>
    </footer>
</body>
</html>
