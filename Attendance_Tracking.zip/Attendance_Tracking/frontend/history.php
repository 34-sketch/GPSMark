<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$student = getCurrentStudent();

// Get attendance history
$historyResponse = apiRequest('/attendance/history?student_id=' . urlencode($student['student_id']));
$records = $historyResponse['data']['records'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance History - GPS Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        .modal { display: none; }
        .modal.active { display: flex; }
        .map-modal { height: 400px; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-indigo-600 text-white shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-history text-2xl"></i>
                    <div>
                        <h1 class="text-xl font-bold">Attendance History</h1>
                        <p class="text-sm text-indigo-200"><?= h($student['full_name']) ?></p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="hover:text-indigo-200">
                        <i class="fas fa-home mr-1"></i> Dashboard
                    </a>
                    <a href="logout.php" class="hover:text-indigo-200">
                        <i class="fas fa-sign-out-alt mr-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Summary Cards -->
        <div class="grid md:grid-cols-4 gap-4 mb-6">
            <div class="bg-white rounded-lg shadow p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm">Total Records</p>
                        <p class="text-2xl font-bold text-gray-800"><?= count($records) ?></p>
                    </div>
                    <i class="fas fa-clipboard-list text-3xl text-blue-500"></i>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm">Completed</p>
                        <p class="text-2xl font-bold text-green-600">
                            <?= count(array_filter($records, fn($r) => $r['is_checked_out'])) ?>
                        </p>
                    </div>
                    <i class="fas fa-check-circle text-3xl text-green-500"></i>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm">Active</p>
                        <p class="text-2xl font-bold text-orange-600">
                            <?= count(array_filter($records, fn($r) => !$r['is_checked_out'])) ?>
                        </p>
                    </div>
                    <i class="fas fa-clock text-3xl text-orange-500"></i>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow p-4">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm">Warnings</p>
                        <p class="text-2xl font-bold text-red-600">
                            <?= count(array_filter($records, fn($r) => $r['warning_out_of_radius'])) ?>
                        </p>
                    </div>
                    <i class="fas fa-exclamation-triangle text-3xl text-red-500"></i>
                </div>
            </div>
        </div>

        <!-- Records Table -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="p-6 border-b border-gray-200">
                <h2 class="text-xl font-bold text-gray-800">
                    <i class="fas fa-list mr-2"></i>
                    Attendance Records
                </h2>
            </div>

            <?php if (empty($records)): ?>
                <div class="p-8 text-center text-gray-600">
                    <i class="fas fa-inbox text-5xl mb-4 text-gray-400"></i>
                    <p>No attendance records found.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Date & Time
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Subject
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Location
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Check In
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Check Out
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Status
                                </th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Actions
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($records as $record): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm font-medium text-gray-900">
                                            <?= date('M d, Y', strtotime($record['check_in_time'])) ?>
                                        </div>
                                        <div class="text-xs text-gray-500">
                                            <?= date('g:i A', strtotime($record['check_in_time'])) ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-medium text-gray-900">
                                            <?= h($record['subject_title']) ?>
                                        </div>
                                        <div class="text-xs text-gray-500">
                                            <?= h($record['instructor']) ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                        <i class="fas fa-map-marker-alt mr-1"></i>
                                        <?= h($record['location_name']) ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?= date('g:i A', strtotime($record['check_in_time'])) ?>
                                        </div>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium
                                            <?= $record['check_in_status'] === 'valid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                            <?= h($record['check_in_status']) ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if ($record['check_out_time']): ?>
                                            <div class="text-sm text-gray-900">
                                                <?= date('g:i A', strtotime($record['check_out_time'])) ?>
                                            </div>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium
                                                <?= $record['check_out_status'] === 'valid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                                <?= h($record['check_out_status']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-xs text-orange-600 font-semibold">
                                                <i class="fas fa-clock mr-1"></i>
                                                Active
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap">
                                        <?php if ($record['warning_out_of_radius']): ?>
                                            <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800">
                                                <i class="fas fa-exclamation-triangle mr-1"></i>
                                                Warning
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
                                                <i class="fas fa-check mr-1"></i>
                                                Normal
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <button onclick="viewDetails('<?= h($record['attendance_id']) ?>')" 
                                                class="text-indigo-600 hover:text-indigo-900">
                                            <i class="fas fa-eye mr-1"></i>
                                            View Map
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Map Modal -->
    <div id="mapModal" class="modal fixed inset-0 bg-black bg-opacity-50 items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-screen overflow-y-auto">
            <div class="p-6 border-b border-gray-200 flex justify-between items-center">
                <h3 class="text-xl font-bold text-gray-800">
                    <i class="fas fa-map-marked-alt mr-2"></i>
                    Attendance Location Tracking
                </h3>
                <button onclick="closeModal()" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times text-2xl"></i>
                </button>
            </div>
            <div class="p-6">
                <div id="trackingMap" class="map-modal rounded-lg mb-4"></div>
                <div id="trackingInfo" class="space-y-2"></div>
                <div id="violationsInfo" class="mt-4"></div>
            </div>
        </div>
    </div>

    <script>
        const API_BASE_URL = '<?= API_BASE_URL ?>';
        let trackingMap = null;

        async function viewDetails(attendanceId) {
            try {
                // Fetch tracking data
                const trackingResponse = await fetch(`${API_BASE_URL}/attendance/${attendanceId}/tracking`);
                const trackingData = await trackingResponse.json();

                // Fetch violations
                const violationsResponse = await fetch(`${API_BASE_URL}/attendance/${attendanceId}/violations`);
                const violationsData = await violationsResponse.json();

                // Show modal
                document.getElementById('mapModal').classList.add('active');

                // Initialize map if not already
                if (!trackingMap) {
                    trackingMap = L.map('trackingMap');
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: '© OpenStreetMap'
                    }).addTo(trackingMap);
                }

                // Clear existing layers
                trackingMap.eachLayer((layer) => {
                    if (layer instanceof L.Marker || layer instanceof L.Polyline || layer instanceof L.Circle) {
                        trackingMap.removeLayer(layer);
                    }
                });

                const points = trackingData.tracking_points || [];
                
                if (points.length > 0) {
                    // Draw path
                    const latlngs = points.map(p => [p.lat, p.lng]);
                    L.polyline(latlngs, {color: 'blue', weight: 3}).addTo(trackingMap);

                    // Add markers
                    const startPoint = points[0];
                    L.marker([startPoint.lat, startPoint.lng], {
                        icon: L.divIcon({
                            className: 'custom-marker',
                            html: '<div style="background: green; width: 20px; height: 20px; border-radius: 50%; border: 2px solid white;"></div>'
                        })
                    }).addTo(trackingMap).bindPopup('Check In');

                    if (points.length > 1) {
                        const endPoint = points[points.length - 1];
                        L.marker([endPoint.lat, endPoint.lng], {
                            icon: L.divIcon({
                                className: 'custom-marker',
                                html: '<div style="background: red; width: 20px; height: 20px; border-radius: 50%; border: 2px solid white;"></div>'
                            })
                        }).addTo(trackingMap).bindPopup('Check Out / Last Position');
                    }

                    // Fit bounds
                    trackingMap.fitBounds(latlngs);

                    // Display info
                    document.getElementById('trackingInfo').innerHTML = `
                        <div class="bg-blue-50 p-4 rounded-lg">
                            <p class="font-semibold text-blue-800">Tracking Summary</p>
                            <p class="text-sm text-blue-700">Total tracking points: ${points.length}</p>
                            <p class="text-sm text-blue-700">Duration: ${formatDuration(points)}</p>
                        </div>
                    `;
                } else {
                    document.getElementById('trackingInfo').innerHTML = `
                        <div class="bg-gray-50 p-4 rounded-lg text-center text-gray-600">
                            No tracking data available
                        </div>
                    `;
                }

                // Display violations
                const violations = violationsData.violations || [];
                if (violations.length > 0) {
                    violations.forEach(v => {
                        L.marker([v.violation_lat, v.violation_lng], {
                            icon: L.divIcon({
                                className: 'custom-marker',
                                html: '<div style="background: orange; width: 15px; height: 15px; border-radius: 50%; border: 2px solid white;"></div>'
                            })
                        }).addTo(trackingMap).bindPopup(`Geofence Violation<br>Distance: ${v.distance_from_center}m`);
                    });

                    document.getElementById('violationsInfo').innerHTML = `
                        <div class="bg-red-50 p-4 rounded-lg">
                            <p class="font-semibold text-red-800">
                                <i class="fas fa-exclamation-triangle mr-1"></i>
                                Geofence Violations: ${violations.length}
                            </p>
                            <ul class="text-sm text-red-700 mt-2 space-y-1">
                                ${violations.map(v => `
                                    <li>• ${new Date(v.violation_time).toLocaleString()} - Distance: ${v.distance_from_center}m</li>
                                `).join('')}
                            </ul>
                        </div>
                    `;
                } else {
                    document.getElementById('violationsInfo').innerHTML = `
                        <div class="bg-green-50 p-4 rounded-lg">
                            <p class="font-semibold text-green-800">
                                <i class="fas fa-check-circle mr-1"></i>
                                No geofence violations
                            </p>
                        </div>
                    `;
                }

            } catch (error) {
                alert('Error loading tracking data: ' + error.message);
            }
        }

        function closeModal() {
            document.getElementById('mapModal').classList.remove('active');
        }

        function formatDuration(points) {
            if (points.length < 2) return 'N/A';
            const start = new Date(points[0].recorded_at);
            const end = new Date(points[points.length - 1].recorded_at);
            const diff = Math.floor((end - start) / 1000 / 60); // minutes
            return `${diff} minutes`;
        }

        // Close modal on escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeModal();
        });
    </script>
</body>
</html>
