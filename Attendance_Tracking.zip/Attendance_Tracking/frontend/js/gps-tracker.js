/**
 * GPS Tracker - Real-time location tracking with geofence validation
 */
class GPSTracker {
    constructor(options) {
        this.apiBaseUrl = options.apiBaseUrl;
        this.studentId = options.studentId;
        this.trackingInterval = options.trackingInterval || 10000;
        this.onLocationUpdate = options.onLocationUpdate || (() => {});
        this.onGeofenceViolation = options.onGeofenceViolation || (() => {});
        this.onGeofenceValid = options.onGeofenceValid || (() => {});
        
        this.watchId = null;
        this.trackingTimer = null;
        this.currentAttendanceId = null;
        this.currentPosition = null;
        this.isTracking = false;
    }

    /**
     * Get current position with retry logic
     */
    getCurrentPosition() {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('Geolocation is not supported by your browser'));
                return;
            }

            // First attempt with high accuracy
            navigator.geolocation.getCurrentPosition(
                position => resolve(position),
                error => {
                    console.warn('High accuracy failed, trying with lower accuracy:', error);
                    // Retry with lower accuracy and longer timeout
                    navigator.geolocation.getCurrentPosition(
                        position => resolve(position),
                        error2 => {
                            let message = 'Unable to get your location. Please check your GPS/location settings and try again.';
                            switch(error2.code) {
                                case error2.PERMISSION_DENIED:
                                    message = 'Location permission denied. Please enable location services.';
                                    break;
                                case error2.POSITION_UNAVAILABLE:
                                    message = 'Location information unavailable.';
                                    break;
                                case error2.TIMEOUT:
                                    message = 'Location request timed out. Please try again.';
                                    break;
                            }
                            console.error('Location error:', error2);
                            reject(new Error(message));
                        },
                        {
                            enableHighAccuracy: false,
                            timeout: 30000,
                            maximumAge: 60000
                        }
                    );
                },
                {
                    enableHighAccuracy: true,
                    timeout: 15000,
                    maximumAge: 0
                }
            );
        });
    }

    /**
     * Check in to a subject
     */
    async checkIn(subjectId) {
        try {
            const position = await this.getCurrentPosition();
            
            const response = await fetch(`${this.apiBaseUrl}/attendance/check-in`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    student_id: this.studentId,
                    subject_id: subjectId,
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                })
            });

            const data = await response.json();

            if (response.ok && data.success) {
                // Start tracking
                const geofenceResponse = await fetch(`${this.apiBaseUrl}/subjects?subject_id=${subjectId}`);
                const geofenceData = await geofenceResponse.json();
                
                if (geofenceData.success) {
                    const subject = geofenceData.subject;
                    this.startTracking(data.attendance_id, {
                        lat: subject.geofence_center_lat,
                        lng: subject.geofence_center_lng,
                        radius: subject.geofence_radius_meters
                    });
                }

                return { success: true, data };
            } else {
                return { success: false, error: data.error };
            }
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    /**
     * Check out from attendance
     */
    async checkOut(attendanceId, earlyCheckoutReason = null) {
        try {
            const position = await this.getCurrentPosition();
            
            const requestBody = {
                attendance_id: attendanceId,
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            
            // Add early checkout reason if provided
            if (earlyCheckoutReason) {
                requestBody.early_checkout_reason = earlyCheckoutReason;
            }
            
            const response = await fetch(`${this.apiBaseUrl}/attendance/check-out`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestBody)
            });

            const data = await response.json();

            if (response.ok && data.success) {
                // Stop tracking
                this.stopTracking();
                return { success: true, data };
            } else {
                // Check if early checkout reason is required (even if response is not ok)
                if (data.requires_reason || data.is_early_checkout) {
                    return { 
                        success: false, 
                        error: data.error,
                        requires_reason: true,
                        early_checkout_info: data
                    };
                }
                return { success: false, error: data.error, data };
            }
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    /**
     * Start real-time location tracking
     */
    startTracking(attendanceId, geofence) {
        this.currentAttendanceId = attendanceId;
        this.currentGeofence = geofence;
        this.isTracking = true;

        console.log('Starting GPS tracking...', { attendanceId, geofence });

        // Watch position continuously
        this.watchId = navigator.geolocation.watchPosition(
            (position) => {
                this.currentPosition = position;
                this.onLocationUpdate(position);
            },
            (error) => {
                console.error('Geolocation error:', error);
            },
            {
                enableHighAccuracy: true,
                timeout: 5000,
                maximumAge: 0
            }
        );

        // Send periodic updates to backend
        this.trackingTimer = setInterval(() => {
            this.sendLocationUpdate();
        }, this.trackingInterval);

        // Send initial update
        this.sendLocationUpdate();
    }

    /**
     * Stop tracking
     */
    stopTracking() {
        console.log('Stopping GPS tracking...');
        
        if (this.watchId !== null) {
            navigator.geolocation.clearWatch(this.watchId);
            this.watchId = null;
        }

        if (this.trackingTimer !== null) {
            clearInterval(this.trackingTimer);
            this.trackingTimer = null;
        }

        this.isTracking = false;
        this.currentAttendanceId = null;
        this.currentGeofence = null;
    }

    /**
     * Send location update to backend
     */
    async sendLocationUpdate() {
        if (!this.isTracking || !this.currentPosition || !this.currentAttendanceId) {
            return;
        }

        try {
            const response = await fetch(`${this.apiBaseUrl}/attendance/track-location`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    attendance_id: this.currentAttendanceId,
                    lat: this.currentPosition.coords.latitude,
                    lng: this.currentPosition.coords.longitude
                })
            });

            const data = await response.json();

            if (data.success) {
                if (!data.is_within_geofence) {
                    // Geofence violation
                    this.onGeofenceViolation(data);
                } else {
                    // Within geofence
                    this.onGeofenceValid(data);
                }
            }
        } catch (error) {
            console.error('Error sending location update:', error);
        }
    }

    /**
     * Calculate distance between two points (Haversine formula)
     */
    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371000; // Earth's radius in meters
        const φ1 = lat1 * Math.PI / 180;
        const φ2 = lat2 * Math.PI / 180;
        const Δφ = (lat2 - lat1) * Math.PI / 180;
        const Δλ = (lon2 - lon1) * Math.PI / 180;

        const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
                  Math.cos(φ1) * Math.cos(φ2) *
                  Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return R * c; // Distance in meters
    }

    /**
     * Check if current position is within geofence
     */
    isWithinGeofence() {
        if (!this.currentPosition || !this.currentGeofence) {
            return false;
        }

        const distance = this.calculateDistance(
            this.currentPosition.coords.latitude,
            this.currentPosition.coords.longitude,
            this.currentGeofence.lat,
            this.currentGeofence.lng
        );

        return distance <= this.currentGeofence.radius;
    }
}

// Make it available globally
if (typeof window !== 'undefined') {
    window.GPSTracker = GPSTracker;
}
