<?php
require_once 'config.php';

// If already logged in, redirect to dashboard
if (isLoggedIn()) {
    redirect('dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = trim($_POST['student_id'] ?? '');
    
    if (empty($student_id)) {
        $error = 'Please enter your Student ID';
    } else {
        // Call API to verify student
        $response = apiRequest('/students?student_id=' . urlencode($student_id));
        
        if ($response['status'] === 200 && isset($response['data']['student'])) {
            $student = $response['data']['student'];
            
            // Set session
            $_SESSION['student_id'] = $student['student_id'];
            $_SESSION['full_name'] = $student['full_name'];
            $_SESSION['program_or_grade'] = $student['program_or_grade'];
            
            redirect('dashboard.php');
        } else {
            $error = 'Student ID not found. Please register first.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login - GPS Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-100 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-md mx-auto">
            <!-- Header -->
            <div class="text-center mb-8">
                <div class="inline-block p-4 bg-indigo-600 rounded-full mb-4">
                    <i class="fas fa-map-marker-alt text-white text-3xl"></i>
                </div>
                <h1 class="text-3xl font-bold text-gray-800 mb-2">GPS Attendance System</h1>
                <p class="text-gray-600">Login to track your attendance</p>
            </div>

            <!-- Login Form -->
            <div class="bg-white rounded-lg shadow-xl p-8">
                <?php if ($error): ?>
                    <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg flex items-center">
                        <i class="fas fa-exclamation-circle mr-2"></i>
                        <span><?= h($error) ?></span>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" class="space-y-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            <i class="fas fa-id-card mr-1"></i> Student ID
                        </label>
                        <input type="text" name="student_id" required autofocus
                               value="<?= h($_POST['student_id'] ?? '') ?>"
                               class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-lg"
                               placeholder="Enter your Student ID">
                    </div>

                    <button type="submit" 
                            class="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition duration-200 flex items-center justify-center text-lg">
                        <i class="fas fa-sign-in-alt mr-2"></i>
                        Login
                    </button>
                </form>

                <div class="mt-6 text-center">
                    <p class="text-gray-600">Don't have an account?</p>
                    <a href="register.php" class="text-indigo-600 hover:text-indigo-800 font-semibold">
                        Register here
                    </a>
                </div>
            </div>

            <!-- Quick Access -->
            <div class="mt-6 grid grid-cols-2 gap-4">
                <a href="admin/index.php" 
                   class="bg-white p-4 rounded-lg shadow hover:shadow-lg transition text-center">
                    <i class="fas fa-user-shield text-purple-600 text-2xl mb-2"></i>
                    <p class="text-sm font-semibold text-gray-700">Admin Dashboard</p>
                </a>
                <a href="subjects.php" 
                   class="bg-white p-4 rounded-lg shadow hover:shadow-lg transition text-center">
                    <i class="fas fa-book text-green-600 text-2xl mb-2"></i>
                    <p class="text-sm font-semibold text-gray-700">View Subjects</p>
                </a>
            </div>

            <!-- Features -->
            <div class="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 class="font-semibold text-blue-800 mb-3 text-center">
                    <i class="fas fa-star mr-1"></i> Features
                </h3>
                <div class="grid grid-cols-2 gap-3 text-sm text-blue-700">
                    <div class="flex items-start">
                        <i class="fas fa-check-circle mr-2 mt-1"></i>
                        <span>Real-time GPS tracking</span>
                    </div>
                    <div class="flex items-start">
                        <i class="fas fa-check-circle mr-2 mt-1"></i>
                        <span>Geofence validation</span>
                    </div>
                    <div class="flex items-start">
                        <i class="fas fa-check-circle mr-2 mt-1"></i>
                        <span>Check-in/out system</span>
                    </div>
                    <div class="flex items-start">
                        <i class="fas fa-check-circle mr-2 mt-1"></i>
                        <span>Attendance history</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
