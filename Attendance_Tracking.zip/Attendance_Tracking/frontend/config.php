<?php
/**
 * GPS Attendance Tracking System - Configuration
 */

// Timezone Configuration
date_default_timezone_set('Asia/Manila');

// API Configuration
define('API_BASE_URL', 'http://localhost:5000/api');

// Database Configuration (for direct PHP queries if needed)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'gps_attendance');
define('DB_CHARSET', 'utf8mb4');

// Tracking Configuration
define('TRACKING_INTERVAL_MS', 10000); // 10 seconds in milliseconds
define('GEOFENCE_WARNING_ENABLED', true);

// Map Configuration
define('DEFAULT_MAP_CENTER_LAT', 14.5995);
define('DEFAULT_MAP_CENTER_LNG', 120.9842);
define('DEFAULT_MAP_ZOOM', 15);

// Session Configuration
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Make API request to Python backend
 */
function apiRequest($endpoint, $method = 'GET', $data = null) {
    $url = API_BASE_URL . $endpoint;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    
    if ($data !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen(json_encode($data))
        ]);
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return [
        'status' => $httpCode,
        'data' => json_decode($response, true)
    ];
}

/**
 * Get database connection
 */
function getDbConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASSWORD);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        error_log("Database connection error: " . $e->getMessage());
        return null;
    }
}

/**
 * Sanitize output
 */
function h($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

/**
 * Check if user is logged in (student)
 */
function isLoggedIn() {
    return isset($_SESSION['student_id']);
}

/**
 * Get current student
 */
function getCurrentStudent() {
    if (isLoggedIn()) {
        return [
            'student_id' => $_SESSION['student_id'],
            'full_name' => $_SESSION['full_name'] ?? '',
            'program_or_grade' => $_SESSION['program_or_grade'] ?? ''
        ];
    }
    return null;
}

/**
 * Redirect helper
 */
function redirect($url) {
    header("Location: $url");
    exit;
}
