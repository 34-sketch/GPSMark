<?php
require_once '../config.php';

// Handle CSV export
if (isset($_GET['action']) && $_GET['action'] === 'export') {
    $params = [];
    if (!empty($_GET['date_from'])) $params[] = 'date_from=' . urlencode($_GET['date_from']);
    if (!empty($_GET['date_to'])) $params[] = 'date_to=' . urlencode($_GET['date_to']);
    
    $queryString = !empty($params) ? '?' . implode('&', $params) : '';
    $response = apiRequest('/admin/export-csv' . $queryString);
    
    if ($response['status'] === 200 && isset($response['data']['csv_data'])) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="attendance_export_' . date('Y-m-d') . '.csv"');
        echo $response['data']['csv_data'];
        exit;
    }
}

// Get filter parameters
$filters = [
    'student_id' => $_GET['student_id'] ?? '',
    'subject_id' => $_GET['subject_id'] ?? '',
    'date_from' => $_GET['date_from'] ?? '',
    'date_to' => $_GET['date_to'] ?? ''
];

// Build query string
$queryParams = array_filter($filters);
$queryString = !empty($queryParams) ? '?' . http_build_query($queryParams) : '';

// Get attendance records
$response = apiRequest('/attendance/history' . $queryString);
$records = $response['data']['records'] ?? [];

// Get students and subjects for filters
$studentsResponse = apiRequest('/students');
$students = $studentsResponse['data']['students'] ?? [];

$subjectsResponse = apiRequest('/subjects');
$subjects = $subjectsResponse['data']['subjects'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        .modal { display: none; }
        .modal.active { display: flex; }
        .map-modal { height: 500px; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-purple-600 text-white shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-chart-bar text-2xl"></i>
                    <div>
                        <h1 class="text-xl font-bold">Reports & Analytics</h1>
                        <p class="text-sm text-purple-200">GPS Attendance System</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="index.php" class="hover:text-purple-200">
                        <i class="fas fa-home mr-1"></i> Dashboard
                    </a>
                    <a href="students.php" class="hover:text-purple-200">
                        <i class="fas fa-users mr-1"></i> Students
                    </a>
                    <a href="subjects.php" class="hover:text-purple-200">
                        <i class="fas fa-book mr-1"></i> Subjects
                    </a>
                    <a href="enrollments.php" class="hover:text-purple-200">
                        <i class="fas fa-user-graduate mr-1"></i> Enrollments
                    </a>
                    <a href="reports.php" class="hover:text-purple-200">
                        <i class="fas fa-chart-bar mr-1"></i> Reports
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Filters -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">
                <i class="fas fa-filter mr-2"></i>
                Filters
            </h2>
            <form method="GET" action="" class="grid md:grid-cols-5 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Student</label>
                    <select name="student_id" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                        <option value="">All Students</option>
                        <?php foreach ($students as $student): ?>
                            <option value="<?= h($student['student_id']) ?>" 
                                    <?= $filters['student_id'] === $student['student_id'] ? 'selected' : '' ?>>
                                <?= h($student['full_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                    <select name="subject_id" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                        <option value="">All Subjects</option>
                        <?php foreach ($subjects as $subject): ?>
                            <option value="<?= h($subject['subject_id']) ?>" 
                                    <?= $filters['subject_id'] === $subject['subject_id'] ? 'selected' : '' ?>>
                                <?= h($subject['title']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date From</label>
                    <input type="date" name="date_from" value="<?= h($filters['date_from']) ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Date To</label>
                    <input type="date" name="date_to" value="<?= h($filters['date_to']) ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                </div>

                <div class="flex items-end space-x-2">
                    <button type="submit" class="flex-1 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition">
                        <i class="fas fa-search mr-2"></i>
                        Filter
                    </button>
                    <a href="reports.php" class="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition">
                        <i class="fas fa-redo"></i>
                    </a>
                </div>
            </form>

            <!-- Export Button -->
            <div class="mt-4 flex justify-end">
                <a href="?action=export<?= !empty($queryParams) ? '&' . http_build_query($queryParams) : '' ?>" 
                   class="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition">
                    <i class="fas fa-download mr-2"></i>
                    Export to CSV
                </a>
            </div>
        </div>

        <!-- Summary Stats -->
        <div class="grid md:grid-cols-4 gap-4 mb-6">
            <div class="bg-white rounded-lg shadow p-4">
                <p class="text-gray-600 text-sm mb-1">Total Records</p>
                <p class="text-3xl font-bold text-blue-600"><?= count($records) ?></p>
            </div>
            <div class="bg-white rounded-lg shadow p-4">
                <p class="text-gray-600 text-sm mb-1">Completed</p>
                <p class="text-3xl font-bold text-green-600">
                    <?= count(array_filter($records, fn($r) => $r['is_checked_out'])) ?>
                </p>
            </div>
            <div class="bg-white rounded-lg shadow p-4">
                <p class="text-gray-600 text-sm mb-1">Active</p>
                <p class="text-3xl font-bold text-orange-600">
                    <?= count(array_filter($records, fn($r) => !$r['is_checked_out'])) ?>
                </p>
            </div>
            <div class="bg-white rounded-lg shadow p-4">
                <p class="text-gray-600 text-sm mb-1">With Warnings</p>
                <p class="text-3xl font-bold text-red-600">
                    <?= count(array_filter($records, fn($r) => $r['warning_out_of_radius'])) ?>
                </p>
            </div>
        </div>

        <!-- Records Table -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="p-6 border-b border-gray-200">
                <h2 class="text-xl font-bold text-gray-800">
                    <i class="fas fa-table mr-2"></i>
                    Attendance Records
                </h2>
            </div>

            <?php if (empty($records)): ?>
                <div class="p-8 text-center text-gray-600">
                    <i class="fas fa-inbox text-5xl mb-4 text-gray-400"></i>
                    <p>No records found matching your filters.</p>
                </div>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subject</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Check In</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Check Out</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Duration</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($records as $record): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-4 py-3">
                                        <div class="text-sm font-medium text-gray-900"><?= h($record['full_name']) ?></div>
                                        <div class="text-xs text-gray-500"><?= h($record['student_id']) ?></div>
                                    </td>
                                    <td class="px-4 py-3">
                                        <div class="text-sm font-medium text-gray-900"><?= h($record['subject_title']) ?></div>
                                        <div class="text-xs text-gray-500"><?= h($record['location_name']) ?></div>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-600">
                                        <?= date('M d, Y', strtotime($record['check_in_time'])) ?>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap">
                                        <div class="text-sm text-gray-900"><?= date('g:i A', strtotime($record['check_in_time'])) ?></div>
                                        <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium
                                            <?= $record['check_in_status'] === 'valid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                            <?= h($record['check_in_status']) ?>
                                        </span>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap">
                                        <?php if ($record['check_out_time']): ?>
                                            <div class="text-sm text-gray-900"><?= date('g:i A', strtotime($record['check_out_time'])) ?></div>
                                            <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium
                                                <?= $record['check_out_status'] === 'valid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                                <?= h($record['check_out_status']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-xs text-orange-600 font-semibold">Active</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap text-sm text-gray-600">
                                        <?php
                                        if ($record['check_out_time']) {
                                            $start = new DateTime($record['check_in_time']);
                                            $end = new DateTime($record['check_out_time']);
                                            $diff = $start->diff($end);
                                            echo $diff->h . 'h ' . $diff->i . 'm';
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap">
                                        <?php if ($record['warning_out_of_radius']): ?>
                                            <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800">
                                                <i class="fas fa-exclamation-triangle mr-1"></i> Warning
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
                                                <i class="fas fa-check mr-1"></i> Normal
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap text-sm">
                                        <button onclick="viewMap('<?= h($record['attendance_id']) ?>')" 
                                                class="text-purple-600 hover:text-purple-900">
                                            <i class="fas fa-map-marked-alt mr-1"></i>
                                            Map
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Map Modal -->
    <div id="mapModal" class="modal fixed inset-0 bg-black bg-opacity-50 items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-6xl w-full mx-4 max-h-screen overflow-y-auto">
            <div class="p-6 border-b border-gray-200 flex justify-between items-center">
                <h3 class="text-xl font-bold text-gray-800">
                    <i class="fas fa-map-marked-alt mr-2"></i>
                    Location Tracking & Geofence Analysis
                </h3>
                <button onclick="closeModal()" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times text-2xl"></i>
                </button>
            </div>
            <div class="p-6">
                <div id="attendanceInfo" class="mb-4"></div>
                <div id="trackingMap" class="map-modal rounded-lg mb-4 border-2 border-gray-200"></div>
                <div class="grid md:grid-cols-2 gap-4">
                    <div id="trackingStats" class="bg-blue-50 p-4 rounded-lg"></div>
                    <div id="violationsInfo" class="bg-red-50 p-4 rounded-lg"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const API_BASE_URL = '<?= API_BASE_URL ?>';
        let trackingMap = null;

        async function viewMap(attendanceId) {
            try {
                // Fetch attendance details
                const historyResponse = await fetch(`${API_BASE_URL}/attendance/history`);
                const historyData = await historyResponse.json();
                const attendance = historyData.records.find(r => r.attendance_id === attendanceId);

                // Fetch tracking data
                const trackingResponse = await fetch(`${API_BASE_URL}/attendance/${attendanceId}/tracking`);
                const trackingData = await trackingResponse.json();

                // Fetch violations
                const violationsResponse = await fetch(`${API_BASE_URL}/attendance/${attendanceId}/violations`);
                const violationsData = await violationsResponse.json();

                // Fetch subject details
                const subjectResponse = await fetch(`${API_BASE_URL}/subjects?subject_id=${attendance.subject_id}`);
                const subjectData = await subjectResponse.json();
                const subject = subjectData.subject;

                // Show modal
                document.getElementById('mapModal').classList.add('active');

                // Display attendance info
                document.getElementById('attendanceInfo').innerHTML = `
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <div class="grid md:grid-cols-3 gap-4">
                            <div>
                                <p class="text-sm text-gray-600">Student</p>
                                <p class="font-semibold text-gray-800">${attendance.full_name}</p>
                                <p class="text-xs text-gray-500">${attendance.student_id}</p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">Subject</p>
                                <p class="font-semibold text-gray-800">${attendance.subject_title}</p>
                                <p class="text-xs text-gray-500">${attendance.location_name}</p>
                            </div>
                            <div>
                                <p class="text-sm text-gray-600">Date & Time</p>
                                <p class="font-semibold text-gray-800">${new Date(attendance.check_in_time).toLocaleDateString()}</p>
                                <p class="text-xs text-gray-500">${new Date(attendance.check_in_time).toLocaleTimeString()}</p>
                            </div>
                        </div>
                    </div>
                `;

                // Initialize map
                if (!trackingMap) {
                    trackingMap = L.map('trackingMap');
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: '© OpenStreetMap'
                    }).addTo(trackingMap);
                } else {
                    // Clear existing layers
                    trackingMap.eachLayer((layer) => {
                        if (!(layer instanceof L.TileLayer)) {
                            trackingMap.removeLayer(layer);
                        }
                    });
                }

                // Add geofence circle
                const geofenceCircle = L.circle([subject.geofence_center_lat, subject.geofence_center_lng], {
                    radius: subject.geofence_radius_meters,
                    color: '#8b5cf6',
                    fillColor: '#c4b5fd',
                    fillOpacity: 0.2,
                    weight: 2
                }).addTo(trackingMap);

                // Add center marker
                L.marker([subject.geofence_center_lat, subject.geofence_center_lng], {
                    icon: L.divIcon({
                        className: 'custom-marker',
                        html: '<div style="background: #8b5cf6; width: 30px; height: 30px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>'
                    })
                }).addTo(trackingMap).bindPopup(`<b>${subject.location_name}</b><br>Geofence Center<br>Radius: ${subject.geofence_radius_meters}m`);

                const points = trackingData.tracking_points || [];
                
                if (points.length > 0) {
                    // Draw path
                    const latlngs = points.map(p => [p.lat, p.lng]);
                    const pathLine = L.polyline(latlngs, {
                        color: '#3b82f6',
                        weight: 3,
                        opacity: 0.7
                    }).addTo(trackingMap);

                    // Add start marker (green)
                    const startPoint = points[0];
                    L.marker([startPoint.lat, startPoint.lng], {
                        icon: L.divIcon({
                            className: 'custom-marker',
                            html: '<div style="background: #10b981; width: 25px; height: 25px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>'
                        })
                    }).addTo(trackingMap).bindPopup(`<b>Check In</b><br>${new Date(startPoint.recorded_at).toLocaleTimeString()}`);

                    // Add end marker (red) if checked out
                    if (points.length > 1 && attendance.is_checked_out) {
                        const endPoint = points[points.length - 1];
                        L.marker([endPoint.lat, endPoint.lng], {
                            icon: L.divIcon({
                                className: 'custom-marker',
                                html: '<div style="background: #ef4444; width: 25px; height: 25px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>'
                            })
                        }).addTo(trackingMap).bindPopup(`<b>Check Out</b><br>${new Date(endPoint.recorded_at).toLocaleTimeString()}`);
                    }

                    // Add violation markers (orange)
                    const violations = violationsData.violations || [];
                    violations.forEach((v, idx) => {
                        L.marker([v.violation_lat, v.violation_lng], {
                            icon: L.divIcon({
                                className: 'custom-marker',
                                html: '<div style="background: #f59e0b; width: 20px; height: 20px; border-radius: 50%; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>'
                            })
                        }).addTo(trackingMap).bindPopup(`<b>Violation #${idx + 1}</b><br>Distance: ${v.distance_from_center.toFixed(2)}m<br>${new Date(v.violation_time).toLocaleTimeString()}`);
                    });

                    // Fit bounds to show all markers
                    const bounds = L.latLngBounds(latlngs);
                    bounds.extend([subject.geofence_center_lat, subject.geofence_center_lng]);
                    trackingMap.fitBounds(bounds, { padding: [50, 50] });

                    // Display tracking stats
                    const insideCount = points.filter(p => p.is_within_geofence).length;
                    const outsideCount = points.length - insideCount;
                    const duration = calculateDuration(points);

                    document.getElementById('trackingStats').innerHTML = `
                        <h4 class="font-semibold text-blue-800 mb-3">
                            <i class="fas fa-chart-line mr-2"></i>Tracking Statistics
                        </h4>
                        <div class="space-y-2 text-sm text-blue-700">
                            <p><i class="fas fa-map-pin mr-2 w-4"></i><b>Total Points:</b> ${points.length}</p>
                            <p><i class="fas fa-check-circle mr-2 w-4"></i><b>Inside Geofence:</b> ${insideCount} (${((insideCount/points.length)*100).toFixed(1)}%)</p>
                            <p><i class="fas fa-exclamation-circle mr-2 w-4"></i><b>Outside Geofence:</b> ${outsideCount} (${((outsideCount/points.length)*100).toFixed(1)}%)</p>
                            <p><i class="fas fa-clock mr-2 w-4"></i><b>Duration:</b> ${duration}</p>
                            <p><i class="fas fa-circle-notch mr-2 w-4"></i><b>Geofence Radius:</b> ${subject.geofence_radius_meters}m</p>
                        </div>
                    `;

                    // Display violations
                    if (violations.length > 0) {
                        document.getElementById('violationsInfo').innerHTML = `
                            <h4 class="font-semibold text-red-800 mb-3">
                                <i class="fas fa-exclamation-triangle mr-2"></i>Geofence Violations (${violations.length})
                            </h4>
                            <div class="space-y-2 text-sm text-red-700 max-h-48 overflow-y-auto">
                                ${violations.map((v, idx) => `
                                    <div class="bg-white p-2 rounded border border-red-200">
                                        <p class="font-semibold">Violation #${idx + 1}</p>
                                        <p class="text-xs">${new Date(v.violation_time).toLocaleString()}</p>
                                        <p class="text-xs">Distance: ${v.distance_from_center.toFixed(2)}m from center</p>
                                    </div>
                                `).join('')}
                            </div>
                        `;
                    } else {
                        document.getElementById('violationsInfo').innerHTML = `
                            <h4 class="font-semibold text-green-800 mb-3">
                                <i class="fas fa-check-circle mr-2"></i>No Violations
                            </h4>
                            <p class="text-sm text-green-700">Student remained within the geofence throughout the session.</p>
                        `;
                    }
                } else {
                    trackingMap.setView([subject.geofence_center_lat, subject.geofence_center_lng], 17);
                    document.getElementById('trackingStats').innerHTML = `
                        <p class="text-gray-600 text-center py-4">No tracking data available</p>
                    `;
                    document.getElementById('violationsInfo').innerHTML = '';
                }

            } catch (error) {
                console.error('Error:', error);
                alert('Error loading map data: ' + error.message);
            }
        }

        function closeModal() {
            document.getElementById('mapModal').classList.remove('active');
        }

        function calculateDuration(points) {
            if (points.length < 2) return 'N/A';
            const start = new Date(points[0].recorded_at);
            const end = new Date(points[points.length - 1].recorded_at);
            const diff = Math.floor((end - start) / 1000 / 60);
            const hours = Math.floor(diff / 60);
            const minutes = diff % 60;
            return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
        }

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeModal();
        });
    </script>
</body>
</html>
