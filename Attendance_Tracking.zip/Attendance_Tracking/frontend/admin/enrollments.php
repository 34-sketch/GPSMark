<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Enrollments - GPS Attendance Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .modal { display: none; }
        .modal.active { display: flex; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-purple-600 text-white shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-user-graduate text-2xl"></i>
                    <div>
                        <h1 class="text-xl font-bold">GPS Attendance - Admin</h1>
                        <p class="text-sm text-purple-200">Enrollment Management</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="index.php" class="hover:text-purple-200">
                        <i class="fas fa-dashboard mr-1"></i> Dashboard
                    </a>
                    <a href="students.php" class="hover:text-purple-200">
                        <i class="fas fa-users mr-1"></i> Students
                    </a>
                    <a href="subjects.php" class="hover:text-purple-200">
                        <i class="fas fa-book mr-1"></i> Subjects
                    </a>
                    <a href="enrollments.php" class="text-white font-bold">
                        <i class="fas fa-user-plus mr-1"></i> Enrollments
                    </a>
                    <a href="reports.php" class="hover:text-purple-200">
                        <i class="fas fa-chart-bar mr-1"></i> Reports
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-3xl font-bold text-gray-800">
                <i class="fas fa-user-graduate mr-2"></i>
                Student Enrollments
            </h2>
            <button onclick="openEnrollModal()" class="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition">
                <i class="fas fa-plus mr-2"></i>
                Enroll Student
            </button>
        </div>

        <!-- Filter Section -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <div class="grid md:grid-cols-3 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Filter by Student</label>
                    <select id="filterStudent" onchange="filterEnrollments()" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                        <option value="">All Students</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Filter by Subject</label>
                    <select id="filterSubject" onchange="filterEnrollments()" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                        <option value="">All Subjects</option>
                    </select>
                </div>
                <div class="flex items-end">
                    <button onclick="clearFilters()" class="w-full px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition">
                        <i class="fas fa-times mr-2"></i>
                        Clear Filters
                    </button>
                </div>
            </div>
        </div>

        <!-- Enrollments Table -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Student</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subject</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Enrolled Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="enrollmentsTable" class="bg-white divide-y divide-gray-200">
                        <!-- Will be populated by JavaScript -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Empty State -->
        <div id="emptyState" class="hidden text-center py-12">
            <i class="fas fa-user-graduate text-6xl text-gray-300 mb-4"></i>
            <p class="text-xl text-gray-500">No enrollments found</p>
        </div>
    </div>

    <!-- Enroll Student Modal -->
    <div id="enrollModal" class="modal fixed inset-0 bg-black bg-opacity-50 items-center justify-center z-50">
        <div class="bg-white rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-screen overflow-y-auto">
            <div class="p-6 border-b border-gray-200">
                <div class="flex justify-between items-center">
                    <h3 class="text-2xl font-bold text-gray-800">
                        <i class="fas fa-user-plus mr-2"></i>
                        Enroll Student in Subject
                    </h3>
                    <button onclick="closeEnrollModal()" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times text-2xl"></i>
                    </button>
                </div>
            </div>

            <form id="enrollForm" class="p-6">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            Select Student <span class="text-red-500">*</span>
                        </label>
                        <select id="enrollStudentId" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                            <option value="">-- Select Student --</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">
                            Select Subject(s) <span class="text-red-500">*</span>
                        </label>
                        <div id="subjectCheckboxes" class="border border-gray-300 rounded-lg p-4 max-h-64 overflow-y-auto space-y-2">
                            <!-- Will be populated by JavaScript -->
                        </div>
                    </div>

                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <p class="text-sm text-blue-800">
                            <i class="fas fa-info-circle mr-2"></i>
                            Select one or more subjects to enroll the student. The student will only see these subjects in their dashboard.
                        </p>
                    </div>
                </div>

                <div class="flex justify-end space-x-3 mt-6">
                    <button type="button" onclick="closeEnrollModal()" class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
                        Cancel
                    </button>
                    <button type="submit" class="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                        <i class="fas fa-save mr-2"></i>
                        Enroll Student
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const API_BASE_URL = 'http://localhost:5000/api';
        let allEnrollments = [];
        let allStudents = [];
        let allSubjects = [];

        // Load data on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadStudents();
            loadSubjects();
            loadEnrollments();
        });

        async function loadStudents() {
            try {
                const response = await fetch(`${API_BASE_URL}/students`);
                const data = await response.json();
                allStudents = data.students || [];
                
                // Populate filter dropdown
                const filterSelect = document.getElementById('filterStudent');
                const enrollSelect = document.getElementById('enrollStudentId');
                
                allStudents.forEach(student => {
                    const option1 = document.createElement('option');
                    option1.value = student.student_id;
                    option1.textContent = `${student.full_name} (${student.student_id})`;
                    filterSelect.appendChild(option1);

                    const option2 = document.createElement('option');
                    option2.value = student.student_id;
                    option2.textContent = `${student.full_name} (${student.student_id})`;
                    enrollSelect.appendChild(option2);
                });
            } catch (error) {
                console.error('Error loading students:', error);
            }
        }

        async function loadSubjects() {
            try {
                const response = await fetch(`${API_BASE_URL}/subjects`);
                const data = await response.json();
                allSubjects = data.subjects || [];
                
                // Populate filter dropdown
                const filterSelect = document.getElementById('filterSubject');
                allSubjects.forEach(subject => {
                    const option = document.createElement('option');
                    option.value = subject.subject_id;
                    option.textContent = `${subject.title} (${subject.subject_id})`;
                    filterSelect.appendChild(option);
                });

                // Populate checkboxes in modal
                const checkboxContainer = document.getElementById('subjectCheckboxes');
                allSubjects.forEach(subject => {
                    const div = document.createElement('div');
                    div.className = 'flex items-center';
                    div.innerHTML = `
                        <input type="checkbox" id="subject_${subject.subject_id}" value="${subject.subject_id}" 
                               class="mr-3 h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded">
                        <label for="subject_${subject.subject_id}" class="text-sm text-gray-700">
                            ${subject.title} - ${subject.instructor || 'No instructor'}
                        </label>
                    `;
                    checkboxContainer.appendChild(div);
                });
            } catch (error) {
                console.error('Error loading subjects:', error);
            }
        }

        async function loadEnrollments() {
            try {
                const response = await fetch(`${API_BASE_URL}/enrollments`);
                const data = await response.json();
                allEnrollments = data.enrollments || [];
                displayEnrollments(allEnrollments);
            } catch (error) {
                console.error('Error loading enrollments:', error);
                alert('Error loading enrollments');
            }
        }

        function displayEnrollments(enrollments) {
            const tbody = document.getElementById('enrollmentsTable');
            const emptyState = document.getElementById('emptyState');
            
            if (enrollments.length === 0) {
                tbody.innerHTML = '';
                emptyState.classList.remove('hidden');
                return;
            }
            
            emptyState.classList.add('hidden');
            tbody.innerHTML = enrollments.map(enrollment => `
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm font-medium text-gray-900">${enrollment.full_name}</div>
                        <div class="text-sm text-gray-500">${enrollment.student_id}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm font-medium text-gray-900">${enrollment.subject_title}</div>
                        <div class="text-sm text-gray-500">${enrollment.subject_id}</div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        ${new Date(enrollment.enrolled_at).toLocaleDateString()}
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            ${enrollment.status}
                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button onclick="unenrollStudent(${enrollment.id})" 
                                class="text-red-600 hover:text-red-900">
                            <i class="fas fa-trash mr-1"></i> Unenroll
                        </button>
                    </td>
                </tr>
            `).join('');
        }

        function filterEnrollments() {
            const studentFilter = document.getElementById('filterStudent').value;
            const subjectFilter = document.getElementById('filterSubject').value;
            
            let filtered = allEnrollments;
            
            if (studentFilter) {
                filtered = filtered.filter(e => e.student_id === studentFilter);
            }
            
            if (subjectFilter) {
                filtered = filtered.filter(e => e.subject_id === subjectFilter);
            }
            
            displayEnrollments(filtered);
        }

        function clearFilters() {
            document.getElementById('filterStudent').value = '';
            document.getElementById('filterSubject').value = '';
            displayEnrollments(allEnrollments);
        }

        function openEnrollModal() {
            document.getElementById('enrollModal').classList.add('active');
        }

        function closeEnrollModal() {
            document.getElementById('enrollModal').classList.remove('active');
            document.getElementById('enrollForm').reset();
        }

        document.getElementById('enrollForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const studentId = document.getElementById('enrollStudentId').value;
            const subjectCheckboxes = document.querySelectorAll('#subjectCheckboxes input[type="checkbox"]:checked');
            const subjectIds = Array.from(subjectCheckboxes).map(cb => cb.value);
            
            if (!studentId) {
                alert('Please select a student');
                return;
            }
            
            if (subjectIds.length === 0) {
                alert('Please select at least one subject');
                return;
            }
            
            try {
                const response = await fetch(`${API_BASE_URL}/enrollments/bulk`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        student_ids: [studentId],
                        subject_ids: subjectIds,
                        enrolled_by: 'admin'
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert(data.message);
                    closeEnrollModal();
                    loadEnrollments();
                } else {
                    alert('Error: ' + (data.error || 'Failed to enroll student'));
                }
            } catch (error) {
                console.error('Error enrolling student:', error);
                alert('Error enrolling student');
            }
        });

        async function unenrollStudent(enrollmentId) {
            if (!confirm('Are you sure you want to unenroll this student from this subject?')) {
                return;
            }
            
            try {
                const response = await fetch(`${API_BASE_URL}/enrollments/${enrollmentId}`, {
                    method: 'DELETE'
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('Student unenrolled successfully');
                    loadEnrollments();
                } else {
                    alert('Error: ' + (data.error || 'Failed to unenroll student'));
                }
            } catch (error) {
                console.error('Error unenrolling student:', error);
                alert('Error unenrolling student');
            }
        }
    </script>
</body>
</html>
