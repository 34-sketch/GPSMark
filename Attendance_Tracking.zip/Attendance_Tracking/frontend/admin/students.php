<?php
require_once '../config.php';

$message = '';
$error = '';

// Handle student operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add') {
            $data = [
                'student_id' => trim($_POST['student_id']),
                'full_name' => trim($_POST['full_name']),
                'program_or_grade' => trim($_POST['program_or_grade']),
                'email' => trim($_POST['email']),
                'phone' => trim($_POST['phone'])
            ];
            
            $response = apiRequest('/students', 'POST', $data);
            if ($response['status'] === 201) {
                $message = 'Student added successfully!';
            } else {
                $error = $response['data']['error'] ?? 'Failed to add student';
            }
        }
    }
}

// Get all students
$studentsResponse = apiRequest('/students');
$students = $studentsResponse['data']['students'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Management - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-purple-600 text-white shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-users text-2xl"></i>
                    <div>
                        <h1 class="text-xl font-bold">Students Management</h1>
                        <p class="text-sm text-purple-200">GPS Attendance System</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="index.php" class="hover:text-purple-200">
                        <i class="fas fa-home mr-1"></i> Dashboard
                    </a>
                    <a href="students.php" class="text-white font-semibold">
                        <i class="fas fa-users mr-1"></i> Students
                    </a>
                    <a href="subjects.php" class="hover:text-purple-200">
                        <i class="fas fa-book mr-1"></i> Subjects
                    </a>
                    <a href="enrollments.php" class="hover:text-purple-200">
                        <i class="fas fa-user-graduate mr-1"></i> Enrollments
                    </a>
                    <a href="reports.php" class="hover:text-purple-200">
                        <i class="fas fa-chart-bar mr-1"></i> Reports
                    </a>
                    <a href="../logout.php" class="hover:text-purple-200">
                        <i class="fas fa-sign-out-alt mr-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <?php if ($message): ?>
            <div class="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg flex items-center">
                <i class="fas fa-check-circle mr-2"></i>
                <span><?= h($message) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <span><?= h($error) ?></span>
            </div>
        <?php endif; ?>

        <div class="grid lg:grid-cols-3 gap-6">
            <!-- Add Student Form -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">
                        <i class="fas fa-user-plus mr-2"></i>
                        Add New Student
                    </h2>
                    <form method="POST" action="" class="space-y-4">
                        <input type="hidden" name="action" value="add">
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Student ID *
                            </label>
                            <input type="text" name="student_id" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   placeholder="e.g., STU001">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Full Name *
                            </label>
                            <input type="text" name="full_name" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   placeholder="Enter full name">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Program / Grade
                            </label>
                            <input type="text" name="program_or_grade"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   placeholder="e.g., Grade 10">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Email
                            </label>
                            <input type="email" name="email"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   placeholder="email@example.com">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Phone
                            </label>
                            <input type="tel" name="phone"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   placeholder="555-0123">
                        </div>

                        <button type="submit" 
                                class="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition font-semibold">
                            <i class="fas fa-plus mr-2"></i>
                            Add Student
                        </button>
                    </form>
                </div>
            </div>

            <!-- Students List -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-lg shadow-md">
                    <div class="p-6 border-b border-gray-200 flex justify-between items-center">
                        <h2 class="text-xl font-bold text-gray-800">
                            <i class="fas fa-list mr-2"></i>
                            All Students (<?= count($students) ?>)
                        </h2>
                        <div class="flex items-center space-x-2">
                            <input type="text" id="searchInput" placeholder="Search students..."
                                   class="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   onkeyup="filterStudents()">
                        </div>
                    </div>

                    <?php if (empty($students)): ?>
                        <div class="p-8 text-center text-gray-600">
                            <i class="fas fa-users text-5xl mb-4 text-gray-400"></i>
                            <p>No students registered yet.</p>
                        </div>
                    <?php else: ?>
                        <div class="overflow-x-auto">
                            <table class="w-full" id="studentsTable">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student ID</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Full Name</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Program/Grade</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Contact</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Registered</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php foreach ($students as $student): ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <span class="text-sm font-medium text-gray-900"><?= h($student['student_id']) ?></span>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap">
                                                <div class="flex items-center">
                                                    <div class="flex-shrink-0 h-10 w-10 bg-purple-100 rounded-full flex items-center justify-center">
                                                        <span class="text-purple-600 font-bold">
                                                            <?= strtoupper(substr($student['full_name'], 0, 1)) ?>
                                                        </span>
                                                    </div>
                                                    <div class="ml-3">
                                                        <p class="text-sm font-medium text-gray-900"><?= h($student['full_name']) ?></p>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                                <?= h($student['program_or_grade'] ?: '-') ?>
                                            </td>
                                            <td class="px-6 py-4 text-sm text-gray-600">
                                                <?php if ($student['email']): ?>
                                                    <p><i class="fas fa-envelope mr-1"></i> <?= h($student['email']) ?></p>
                                                <?php endif; ?>
                                                <?php if ($student['phone']): ?>
                                                    <p><i class="fas fa-phone mr-1"></i> <?= h($student['phone']) ?></p>
                                                <?php endif; ?>
                                                <?php if (!$student['email'] && !$student['phone']): ?>
                                                    <span class="text-gray-400">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                                <?= date('M d, Y', strtotime($student['created_at'])) ?>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm">
                                                <a href="reports.php?student_id=<?= urlencode($student['student_id']) ?>" 
                                                   class="text-purple-600 hover:text-purple-900 mr-3">
                                                    <i class="fas fa-chart-bar mr-1"></i>
                                                    View Records
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function filterStudents() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const table = document.getElementById('studentsTable');
            const rows = table.getElementsByTagName('tr');

            for (let i = 1; i < rows.length; i++) {
                const row = rows[i];
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            }
        }
    </script>
</body>
</html>
