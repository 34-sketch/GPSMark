<?php
require_once '../config.php';

// Get dashboard stats
$statsResponse = apiRequest('/admin/stats');
$stats = $statsResponse['data']['stats'] ?? [];

// Get recent attendance
$recentResponse = apiRequest('/attendance/history');
$recentRecords = array_slice($recentResponse['data']['records'] ?? [], 0, 10);

// Get all students
$studentsResponse = apiRequest('/students');
$students = $studentsResponse['data']['students'] ?? [];

// Get all subjects
$subjectsResponse = apiRequest('/subjects');
$subjects = $subjectsResponse['data']['subjects'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - GPS Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        /* Custom scrollbar styling */
        .overflow-y-auto::-webkit-scrollbar {
            width: 8px;
        }
        .overflow-y-auto::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        .overflow-y-auto::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 10px;
        }
        .overflow-y-auto::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-purple-600 text-white shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-user-shield text-2xl"></i>
                    <div>
                        <h1 class="text-xl font-bold">Admin Dashboard</h1>
                        <p class="text-sm text-purple-200">GPS Attendance System</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="index.php" class="text-white font-semibold">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="students.php" class="hover:text-purple-200">
                        <i class="fas fa-users mr-2"></i>Students
                    </a>
                    <a href="subjects.php" class="hover:text-purple-200">
                        <i class="fas fa-book mr-2"></i>Subjects
                    </a>
                    <a href="enrollments.php" class="hover:text-purple-200">
                        <i class="fas fa-user-graduate mr-2"></i>Enrollments
                    </a>
                    <a href="reports.php" class="hover:text-purple-200">
                        <i class="fas fa-chart-bar mr-2"></i>Reports
                    </a>
                    <a href="../logout.php" class="hover:text-purple-200">
                        <i class="fas fa-sign-out-alt mr-2"></i>Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Stats Cards -->
        <div class="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm mb-1">Total Students</p>
                        <p class="text-3xl font-bold text-blue-600"><?= $stats['total_students'] ?? 0 ?></p>
                    </div>
                    <i class="fas fa-users text-4xl text-blue-500 opacity-20"></i>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm mb-1">Total Subjects</p>
                        <p class="text-3xl font-bold text-green-600"><?= $stats['total_subjects'] ?? 0 ?></p>
                    </div>
                    <i class="fas fa-book text-4xl text-green-500 opacity-20"></i>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm mb-1">Total Attendance</p>
                        <p class="text-3xl font-bold text-purple-600"><?= $stats['total_attendance'] ?? 0 ?></p>
                    </div>
                    <i class="fas fa-clipboard-list text-4xl text-purple-500 opacity-20"></i>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm mb-1">Currently Active</p>
                        <p class="text-3xl font-bold text-orange-600"><?= $stats['currently_checked_in'] ?? 0 ?></p>
                    </div>
                    <i class="fas fa-clock text-4xl text-orange-500 opacity-20"></i>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm mb-1">Today's Attendance</p>
                        <p class="text-3xl font-bold text-indigo-600"><?= $stats['attendance_today'] ?? 0 ?></p>
                    </div>
                    <i class="fas fa-calendar-day text-4xl text-indigo-500 opacity-20"></i>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 text-sm mb-1">Violations Today</p>
                        <p class="text-3xl font-bold text-red-600"><?= $stats['violations_today'] ?? 0 ?></p>
                    </div>
                    <i class="fas fa-exclamation-triangle text-4xl text-red-500 opacity-20"></i>
                </div>
            </div>
        </div>

        <!-- Attendance Status Breakdown -->
        <?php 
        $statusBreakdown = $stats['status_breakdown_today'] ?? [];
        $presentCount = $statusBreakdown['present'] ?? 0;
        $lateCount = $statusBreakdown['late'] ?? 0;
        $earlyCheckoutCount = $statusBreakdown['early_checkout'] ?? 0;
        $absentCount = $statusBreakdown['absent'] ?? 0;
        ?>
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4">
                <i class="fas fa-chart-pie mr-2"></i>
                Today's Attendance Status Breakdown
            </h2>
            <div class="grid md:grid-cols-4 gap-4">
                <div class="bg-green-50 border-l-4 border-green-500 p-4 rounded">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-green-600 text-sm font-semibold">Present</p>
                            <p class="text-3xl font-bold text-green-700"><?= $presentCount ?></p>
                        </div>
                        <i class="fas fa-check-circle text-3xl text-green-500 opacity-50"></i>
                    </div>
                </div>
                <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-yellow-600 text-sm font-semibold">Late</p>
                            <p class="text-3xl font-bold text-yellow-700"><?= $lateCount ?></p>
                        </div>
                        <i class="fas fa-clock text-3xl text-yellow-500 opacity-50"></i>
                    </div>
                </div>
                <div class="bg-orange-50 border-l-4 border-orange-500 p-4 rounded">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-orange-600 text-sm font-semibold">Early Checkout</p>
                            <p class="text-3xl font-bold text-orange-700"><?= $earlyCheckoutCount ?></p>
                        </div>
                        <i class="fas fa-sign-out-alt text-3xl text-orange-500 opacity-50"></i>
                    </div>
                </div>
                <div class="bg-red-50 border-l-4 border-red-500 p-4 rounded">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-red-600 text-sm font-semibold">Absent</p>
                            <p class="text-3xl font-bold text-red-700"><?= $absentCount ?></p>
                        </div>
                        <i class="fas fa-times-circle text-3xl text-red-500 opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Real-Time Active Students with Location Status -->
        <?php $activeStudents = $stats['active_students'] ?? []; ?>
        <?php if (!empty($activeStudents)): ?>
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4">
                <i class="fas fa-satellite-dish mr-2"></i>
                Real-Time Active Students & Location Tracking
                <span class="ml-2 text-sm font-normal text-gray-600">(<?= count($activeStudents) ?> active)</span>
            </h2>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Student Info</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subject</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Scheduled Time</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Check-In Time</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Location Status</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($activeStudents as $student): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-4 py-3">
                                <div>
                                    <p class="font-semibold text-gray-800"><?= h($student['full_name']) ?></p>
                                    <p class="text-sm text-gray-600"><?= h($student['student_id']) ?></p>
                                    <p class="text-xs text-gray-500"><?= h($student['program_or_grade']) ?></p>
                                </div>
                            </td>
                            <td class="px-4 py-3">
                                <p class="text-gray-800"><?= h($student['subject_title']) ?></p>
                                <p class="text-xs text-gray-500"><?= h($student['subject_id']) ?></p>
                            </td>
                            <td class="px-4 py-3 text-sm text-gray-600">
                                <?php if ($student['scheduled_start']): ?>
                                    <?= date('g:i A', strtotime($student['scheduled_start'])) ?> - 
                                    <?= date('g:i A', strtotime($student['scheduled_end'])) ?>
                                <?php else: ?>
                                    <span class="text-gray-400">Not set</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-3 text-sm text-gray-600">
                                <?= date('g:i A', strtotime($student['check_in_time'])) ?>
                            </td>
                            <td class="px-4 py-3">
                                <?php
                                $statusColors = [
                                    'present' => 'bg-green-100 text-green-800',
                                    'late' => 'bg-yellow-100 text-yellow-800',
                                    'early_checkout' => 'bg-orange-100 text-orange-800',
                                    'absent' => 'bg-red-100 text-red-800'
                                ];
                                $statusIcons = [
                                    'present' => 'fa-check-circle',
                                    'late' => 'fa-clock',
                                    'early_checkout' => 'fa-sign-out-alt',
                                    'absent' => 'fa-times-circle'
                                ];
                                $statusClass = $statusColors[$student['attendance_status']] ?? 'bg-gray-100 text-gray-800';
                                $statusIcon = $statusIcons[$student['attendance_status']] ?? 'fa-question-circle';
                                ?>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium <?= $statusClass ?>">
                                    <i class="fas <?= $statusIcon ?> mr-1"></i>
                                    <?= ucfirst(str_replace('_', ' ', $student['attendance_status'])) ?>
                                </span>
                            </td>
                            <td class="px-4 py-3">
                                <?php if ($student['current_location_status'] === 1 || $student['current_location_status'] === true): ?>
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                                        <span class="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
                                        Inside Radius ✅
                                    </span>
                                <?php elseif ($student['current_location_status'] === 0 || $student['current_location_status'] === false): ?>
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-800">
                                        <span class="w-2 h-2 bg-red-500 rounded-full mr-2 animate-pulse"></span>
                                        Outside Radius ❌
                                    </span>
                                <?php else: ?>
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">
                                        <i class="fas fa-question-circle mr-1"></i>
                                        No Data
                                    </span>
                                <?php endif; ?>
                                <?php if ($student['warning_out_of_radius']): ?>
                                    <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800 ml-2">
                                        <i class="fas fa-exclamation-triangle mr-1"></i> Alert
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- Weekly Attendance Trend Chart -->
        <?php $weeklyTrend = $stats['weekly_trend'] ?? []; ?>
        <?php if (!empty($weeklyTrend)): ?>
        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 class="text-xl font-bold text-gray-800 mb-4">
                <i class="fas fa-chart-line mr-2"></i>
                Weekly Attendance Trends (Last 7 Days)
            </h2>
            <canvas id="weeklyTrendChart" height="80"></canvas>
        </div>
        <?php endif; ?>

        <div class="grid lg:grid-cols-2 gap-6 mb-8">
            <!-- Recent Attendance -->
            <div class="bg-white rounded-lg shadow-md flex flex-col" style="height: 600px;">
                <div class="p-6 border-b border-gray-200">
                    <h2 class="text-xl font-bold text-gray-800">
                        <i class="fas fa-clock mr-2"></i>
                        Recent Attendance
                    </h2>
                </div>
                <div class="p-6 flex-1 overflow-y-auto">
                    <?php if (empty($recentRecords)): ?>
                        <p class="text-gray-600 text-center py-4">No recent attendance records</p>
                    <?php else: ?>
                        <div class="space-y-3">
                            <?php foreach ($recentRecords as $record): ?>
                                <div class="border border-gray-200 rounded-lg p-3 hover:bg-gray-50">
                                    <div class="flex justify-between items-start">
                                        <div class="flex-1">
                                            <p class="font-semibold text-gray-800"><?= h($record['full_name']) ?></p>
                                            <p class="text-sm text-gray-600"><?= h($record['subject_title']) ?></p>
                                            <p class="text-xs text-gray-500">
                                                <?= date('M d, Y g:i A', strtotime($record['check_in_time'])) ?>
                                            </p>
                                        </div>
                                        <div class="text-right">
                                            <?php if ($record['is_checked_out']): ?>
                                                <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
                                                    <i class="fas fa-check mr-1"></i> Complete
                                                </span>
                                            <?php else: ?>
                                                <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-orange-100 text-orange-800">
                                                    <i class="fas fa-clock mr-1"></i> Active
                                                </span>
                                            <?php endif; ?>
                                            <?php if ($record['warning_out_of_radius']): ?>
                                                <span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800 mt-1">
                                                    <i class="fas fa-exclamation-triangle mr-1"></i> Warning
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="mt-4 text-center">
                            <a href="reports.php" class="text-purple-600 hover:text-purple-800 font-semibold">
                                View All Records <i class="fas fa-arrow-right ml-1"></i>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-white rounded-lg shadow-md flex flex-col" style="height: 600px;">
                <div class="p-6 border-b border-gray-200">
                    <h2 class="text-xl font-bold text-gray-800">
                        <i class="fas fa-bolt mr-2"></i>
                        Quick Actions
                    </h2>
                </div>
                <div class="p-6 flex-1">
                    <div class="grid grid-cols-2 gap-4 h-full content-start">
                        <a href="students.php?action=add" 
                           class="bg-blue-50 hover:bg-blue-100 border-2 border-blue-200 rounded-lg p-6 text-center transition">
                            <i class="fas fa-user-plus text-4xl text-blue-600 mb-3"></i>
                            <p class="font-semibold text-blue-800">Add Student</p>
                        </a>

                        <a href="subjects.php?action=add" 
                           class="bg-green-50 hover:bg-green-100 border-2 border-green-200 rounded-lg p-6 text-center transition">
                            <i class="fas fa-book-medical text-4xl text-green-600 mb-3"></i>
                            <p class="font-semibold text-green-800">Add Subject</p>
                        </a>

                        <a href="reports.php" 
                           class="bg-purple-50 hover:bg-purple-100 border-2 border-purple-200 rounded-lg p-6 text-center transition">
                            <i class="fas fa-chart-line text-4xl text-purple-600 mb-3"></i>
                            <p class="font-semibold text-purple-800">View Reports</p>
                        </a>

                        <a href="reports.php?action=export" 
                           class="bg-orange-50 hover:bg-orange-100 border-2 border-orange-200 rounded-lg p-6 text-center transition">
                            <i class="fas fa-download text-4xl text-orange-600 mb-3"></i>
                            <p class="font-semibold text-orange-800">Export CSV</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Students & Subjects Overview -->
        <div class="grid lg:grid-cols-2 gap-6">
            <!-- Students List -->
            <div class="bg-white rounded-lg shadow-md">
                <div class="p-6 border-b border-gray-200 flex justify-between items-center">
                    <h2 class="text-xl font-bold text-gray-800">
                        <i class="fas fa-users mr-2"></i>
                        Students (<?= count($students) ?>)
                    </h2>
                    <a href="students.php" class="text-blue-600 hover:text-blue-800 text-sm font-semibold">
                        View All <i class="fas fa-arrow-right ml-1"></i>
                    </a>
                </div>
                <div class="p-6">
                    <?php if (empty($students)): ?>
                        <p class="text-gray-600 text-center py-4">No students registered</p>
                    <?php else: ?>
                        <div class="space-y-2 max-h-96 overflow-y-auto">
                            <?php foreach (array_slice($students, 0, 10) as $student): ?>
                                <div class="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                                    <div>
                                        <p class="font-semibold text-gray-800"><?= h($student['full_name']) ?></p>
                                        <p class="text-sm text-gray-600">
                                            <?= h($student['student_id']) ?>
                                            <?php if (!empty($student['program_or_grade'])): ?>
                                                • <?= h($student['program_or_grade']) ?>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <a href="reports.php?student_id=<?= urlencode($student['student_id']) ?>" 
                                       class="text-purple-600 hover:text-purple-800">
                                        <i class="fas fa-chart-bar"></i>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Subjects List -->
            <div class="bg-white rounded-lg shadow-md">
                <div class="p-6 border-b border-gray-200 flex justify-between items-center">
                    <h2 class="text-xl font-bold text-gray-800">
                        <i class="fas fa-book mr-2"></i>
                        Subjects (<?= count($subjects) ?>)
                    </h2>
                    <a href="subjects.php" class="text-green-600 hover:text-green-800 text-sm font-semibold">
                        View All <i class="fas fa-arrow-right ml-1"></i>
                    </a>
                </div>
                <div class="p-6">
                    <?php if (empty($subjects)): ?>
                        <p class="text-gray-600 text-center py-4">No subjects available</p>
                    <?php else: ?>
                        <div class="space-y-2 max-h-96 overflow-y-auto">
                            <?php foreach (array_slice($subjects, 0, 10) as $subject): ?>
                                <div class="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50">
                                    <div>
                                        <p class="font-semibold text-gray-800"><?= h($subject['title']) ?></p>
                                        <p class="text-sm text-gray-600">
                                            <?= h($subject['instructor']) ?> • <?= h($subject['location_name']) ?>
                                        </p>
                                        <p class="text-xs text-gray-500">
                                            <i class="fas fa-clock mr-1"></i>
                                            <?= date('g:i A', strtotime($subject['scheduled_start'])) ?> - 
                                            <?= date('g:i A', strtotime($subject['scheduled_end'])) ?>
                                        </p>
                                    </div>
                                    <a href="reports.php?subject_id=<?= urlencode($subject['subject_id']) ?>" 
                                       class="text-purple-600 hover:text-purple-800">
                                        <i class="fas fa-chart-bar"></i>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Weekly Trend Chart
        <?php if (!empty($weeklyTrend)): ?>
        const weeklyTrendData = <?= json_encode(array_reverse($weeklyTrend)) ?>;
        
        const ctx = document.getElementById('weeklyTrendChart');
        if (ctx) {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: weeklyTrendData.map(d => {
                        const date = new Date(d.date);
                        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
                    }),
                    datasets: [
                        {
                            label: 'Present',
                            data: weeklyTrendData.map(d => d.present || 0),
                            borderColor: 'rgb(34, 197, 94)',
                            backgroundColor: 'rgba(34, 197, 94, 0.1)',
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'Late',
                            data: weeklyTrendData.map(d => d.late || 0),
                            borderColor: 'rgb(234, 179, 8)',
                            backgroundColor: 'rgba(234, 179, 8, 0.1)',
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'Early Checkout',
                            data: weeklyTrendData.map(d => d.early_checkout || 0),
                            borderColor: 'rgb(249, 115, 22)',
                            backgroundColor: 'rgba(249, 115, 22, 0.1)',
                            tension: 0.4,
                            fill: true
                        },
                        {
                            label: 'Total',
                            data: weeklyTrendData.map(d => d.total || 0),
                            borderColor: 'rgb(99, 102, 241)',
                            backgroundColor: 'rgba(99, 102, 241, 0.1)',
                            tension: 0.4,
                            fill: false,
                            borderWidth: 3,
                            borderDash: [5, 5]
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: false
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false,
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            }
                        }
                    },
                    interaction: {
                        mode: 'nearest',
                        axis: 'x',
                        intersect: false
                    }
                }
            });
        }
        <?php endif; ?>

        // Auto-refresh stats every 30 seconds
        setInterval(() => {
            location.reload();
        }, 30000);
    </script>
</body>
</html>
