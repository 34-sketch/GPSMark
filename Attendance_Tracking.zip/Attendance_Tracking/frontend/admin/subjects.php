<?php
require_once '../config.php';

$message = '';
$error = '';

// Handle subject operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        // Handle scheduled days
        $scheduled_days = isset($_POST['scheduled_days']) ? implode(',', $_POST['scheduled_days']) : 'Mon,Tue,Wed,Thu,Fri,Sat,Sun';
        
        $data = [
            'subject_id' => trim($_POST['subject_id']),
            'title' => trim($_POST['title']),
            'instructor' => trim($_POST['instructor']),
            'location_name' => trim($_POST['location_name']),
            'scheduled_start' => $_POST['scheduled_start'],
            'scheduled_end' => $_POST['scheduled_end'],
            'scheduled_days' => $scheduled_days,
            'geofence_center_lat' => floatval($_POST['geofence_center_lat']),
            'geofence_center_lng' => floatval($_POST['geofence_center_lng']),
            'geofence_radius_meters' => intval($_POST['geofence_radius_meters'])
        ];
        
        $response = apiRequest('/subjects', 'POST', $data);
        if ($response['status'] === 201) {
            $message = 'Subject added successfully!';
        } else {
            $error = $response['data']['error'] ?? 'Failed to add subject';
        }
    }
}

// Get all subjects
$subjectsResponse = apiRequest('/subjects');
$subjects = $subjectsResponse['data']['subjects'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subjects Management - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        .map-picker { height: 300px; }
        .subject-map { height: 200px; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-purple-600 text-white shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-book text-2xl"></i>
                    <div>
                        <h1 class="text-xl font-bold">Subjects Management</h1>
                        <p class="text-sm text-purple-200">GPS Attendance System</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="index.php" class="hover:text-purple-200">
                        <i class="fas fa-home mr-1"></i> Dashboard
                    </a>
                    <a href="students.php" class="hover:text-purple-200">
                        <i class="fas fa-users mr-1"></i> Students
                    </a>
                    <a href="subjects.php" class="text-white font-semibold">
                        <i class="fas fa-book mr-1"></i> Subjects
                    </a>
                    <a href="enrollments.php" class="hover:text-purple-200">
                        <i class="fas fa-user-graduate mr-1"></i> Enrollments
                    </a>
                    <a href="reports.php" class="hover:text-purple-200">
                        <i class="fas fa-chart-bar mr-1"></i> Reports
                    </a>
                    <a href="../logout.php" class="hover:text-purple-200">
                        <i class="fas fa-sign-out-alt mr-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <?php if ($message): ?>
            <div class="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg flex items-center">
                <i class="fas fa-check-circle mr-2"></i>
                <span><?= h($message) ?></span>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <span><?= h($error) ?></span>
            </div>
        <?php endif; ?>

        <div class="grid lg:grid-cols-3 gap-6">
            <!-- Add Subject Form -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">
                        <i class="fas fa-book-medical mr-2"></i>
                        Add New Subject
                    </h2>
                    <form method="POST" action="" class="space-y-4">
                        <input type="hidden" name="action" value="add">
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Subject ID *</label>
                            <input type="text" name="subject_id" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   placeholder="e.g., SUBJ001">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Title *</label>
                            <input type="text" name="title" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   placeholder="e.g., Mathematics 101">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Instructor</label>
                            <input type="text" name="instructor"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   placeholder="e.g., Prof. Smith">
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Location Name</label>
                            <input type="text" name="location_name"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   placeholder="e.g., Room 201">
                        </div>

                        <div class="grid grid-cols-2 gap-3">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Start Time</label>
                                <input type="time" name="scheduled_start"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">End Time</label>
                                <input type="time" name="scheduled_end"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Scheduled Days</label>
                            <div class="flex flex-wrap gap-2">
                                <label class="inline-flex items-center">
                                    <input type="checkbox" name="scheduled_days[]" value="Mon" checked class="mr-1">
                                    <span class="text-sm">Monday</span>
                                </label>
                                <label class="inline-flex items-center">
                                    <input type="checkbox" name="scheduled_days[]" value="Tue" checked class="mr-1">
                                    <span class="text-sm">Tuesday</span>
                                </label>
                                <label class="inline-flex items-center">
                                    <input type="checkbox" name="scheduled_days[]" value="Wed" checked class="mr-1">
                                    <span class="text-sm">Wednesday</span>
                                </label>
                                <label class="inline-flex items-center">
                                    <input type="checkbox" name="scheduled_days[]" value="Thu" checked class="mr-1">
                                    <span class="text-sm">Thursday</span>
                                </label>
                                <label class="inline-flex items-center">
                                    <input type="checkbox" name="scheduled_days[]" value="Fri" checked class="mr-1">
                                    <span class="text-sm">Friday</span>
                                </label>
                                <label class="inline-flex items-center">
                                    <input type="checkbox" name="scheduled_days[]" value="Sat" checked class="mr-1">
                                    <span class="text-sm">Saturday</span>
                                </label>
                                <label class="inline-flex items-center">
                                    <input type="checkbox" name="scheduled_days[]" value="Sun" checked class="mr-1">
                                    <span class="text-sm">Sunday</span>
                                </label>
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Geofence Location *
                                <button type="button" onclick="detectLocation()" class="text-purple-600 text-xs ml-2">
                                    <i class="fas fa-crosshairs"></i> Use My Location
                                </button>
                            </label>
                            <div class="grid grid-cols-2 gap-2">
                                <input type="number" step="0.000001" name="geofence_center_lat" id="lat" required
                                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                       placeholder="Latitude" value="14.5995">
                                <input type="number" step="0.000001" name="geofence_center_lng" id="lng" required
                                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                       placeholder="Longitude" value="120.9842">
                            </div>
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Geofence Radius (meters) *
                            </label>
                            <input type="number" name="geofence_radius_meters" required value="50"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
                                   placeholder="e.g., 50">
                        </div>

                        <!-- Map Picker -->
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">
                                Click on map to set location
                            </label>
                            <div id="mapPicker" class="map-picker rounded-lg border-2 border-gray-300"></div>
                        </div>

                        <button type="submit" 
                                class="w-full bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition font-semibold">
                            <i class="fas fa-plus mr-2"></i>
                            Add Subject
                        </button>
                    </form>
                </div>
            </div>

            <!-- Subjects List -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-lg shadow-md">
                    <div class="p-6 border-b border-gray-200">
                        <h2 class="text-xl font-bold text-gray-800">
                            <i class="fas fa-list mr-2"></i>
                            All Subjects (<?= count($subjects) ?>)
                        </h2>
                    </div>

                    <?php if (empty($subjects)): ?>
                        <div class="p-8 text-center text-gray-600">
                            <i class="fas fa-book text-5xl mb-4 text-gray-400"></i>
                            <p>No subjects created yet.</p>
                        </div>
                    <?php else: ?>
                        <div class="p-6 space-y-4">
                            <?php foreach ($subjects as $subject): ?>
                                <div class="border border-gray-200 rounded-lg p-4 hover:shadow-lg transition">
                                    <div class="grid md:grid-cols-2 gap-4">
                                        <div>
                                            <h3 class="text-lg font-bold text-gray-800 mb-2"><?= h($subject['title']) ?></h3>
                                            
                                            <div class="space-y-1 text-sm text-gray-600">
                                                <p><i class="fas fa-id-badge mr-2 w-4"></i> <b>ID:</b> <?= h($subject['subject_id']) ?></p>
                                                
                                                <?php if ($subject['instructor']): ?>
                                                    <p><i class="fas fa-chalkboard-teacher mr-2 w-4"></i> <?= h($subject['instructor']) ?></p>
                                                <?php endif; ?>
                                                
                                                <?php if ($subject['location_name']): ?>
                                                    <p><i class="fas fa-map-marker-alt mr-2 w-4"></i> <?= h($subject['location_name']) ?></p>
                                                <?php endif; ?>
                                                
                                                <?php if ($subject['scheduled_start']): ?>
                                                    <p><i class="fas fa-clock mr-2 w-4"></i> 
                                                        <?= date('g:i A', strtotime($subject['scheduled_start'])) ?> - 
                                                        <?= date('g:i A', strtotime($subject['scheduled_end'])) ?>
                                                    </p>
                                                <?php endif; ?>
                                                
                                                <p><i class="fas fa-circle-notch mr-2 w-4"></i> 
                                                    Radius: <?= h($subject['geofence_radius_meters']) ?>m
                                                </p>
                                                
                                                <p><i class="fas fa-map-pin mr-2 w-4"></i> 
                                                    <?= number_format($subject['geofence_center_lat'], 6) ?>, 
                                                    <?= number_format($subject['geofence_center_lng'], 6) ?>
                                                </p>
                                            </div>

                                            <div class="mt-3">
                                                <a href="reports.php?subject_id=<?= urlencode($subject['subject_id']) ?>" 
                                                   class="text-purple-600 hover:text-purple-900 text-sm font-semibold">
                                                    <i class="fas fa-chart-bar mr-1"></i>
                                                    View Attendance Records
                                                </a>
                                            </div>
                                        </div>

                                        <div>
                                            <div id="map-<?= h($subject['subject_id']) ?>" class="subject-map rounded-lg"></div>
                                        </div>
                                    </div>
                                </div>

                                <script>
                                    (function() {
                                        const map = L.map('map-<?= h($subject['subject_id']) ?>', {
                                            center: [<?= $subject['geofence_center_lat'] ?>, <?= $subject['geofence_center_lng'] ?>],
                                            zoom: 17,
                                            zoomControl: true,
                                            scrollWheelZoom: false
                                        });

                                        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                            attribution: '© OpenStreetMap'
                                        }).addTo(map);

                                        L.circle([<?= $subject['geofence_center_lat'] ?>, <?= $subject['geofence_center_lng'] ?>], {
                                            radius: <?= $subject['geofence_radius_meters'] ?>,
                                            color: '#8b5cf6',
                                            fillColor: '#c4b5fd',
                                            fillOpacity: 0.3
                                        }).addTo(map);

                                        L.marker([<?= $subject['geofence_center_lat'] ?>, <?= $subject['geofence_center_lng'] ?>])
                                            .addTo(map)
                                            .bindPopup('<?= h($subject['location_name']) ?>');
                                    })();
                                </script>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initialize map picker
        const mapPicker = L.map('mapPicker').setView([14.5995, 120.9842], 15);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap'
        }).addTo(mapPicker);

        let marker = L.marker([14.5995, 120.9842], { draggable: true }).addTo(mapPicker);
        let circle = L.circle([14.5995, 120.9842], {
            radius: 50,
            color: '#8b5cf6',
            fillColor: '#c4b5fd',
            fillOpacity: 0.3
        }).addTo(mapPicker);

        // Update coordinates when marker is dragged
        marker.on('dragend', function(e) {
            const pos = marker.getLatLng();
            updateCoordinates(pos.lat, pos.lng);
        });

        // Click on map to place marker
        mapPicker.on('click', function(e) {
            const pos = e.latlng;
            marker.setLatLng(pos);
            circle.setLatLng(pos);
            updateCoordinates(pos.lat, pos.lng);
        });

        // Update radius when input changes
        document.querySelector('input[name="geofence_radius_meters"]').addEventListener('input', function(e) {
            circle.setRadius(parseInt(e.target.value) || 50);
        });

        function updateCoordinates(lat, lng) {
            document.getElementById('lat').value = lat.toFixed(6);
            document.getElementById('lng').value = lng.toFixed(6);
            circle.setLatLng([lat, lng]);
        }

        // Detect current location
        function detectLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    
                    mapPicker.setView([lat, lng], 17);
                    marker.setLatLng([lat, lng]);
                    circle.setLatLng([lat, lng]);
                    updateCoordinates(lat, lng);
                }, function(error) {
                    alert('Unable to detect location: ' + error.message);
                });
            } else {
                alert('Geolocation is not supported by your browser');
            }
        }

        // Manual coordinate input updates
        document.getElementById('lat').addEventListener('change', function() {
            const lat = parseFloat(this.value);
            const lng = parseFloat(document.getElementById('lng').value);
            if (!isNaN(lat) && !isNaN(lng)) {
                mapPicker.setView([lat, lng], 17);
                marker.setLatLng([lat, lng]);
                circle.setLatLng([lat, lng]);
            }
        });

        document.getElementById('lng').addEventListener('change', function() {
            const lat = parseFloat(document.getElementById('lat').value);
            const lng = parseFloat(this.value);
            if (!isNaN(lat) && !isNaN(lng)) {
                mapPicker.setView([lat, lng], 17);
                marker.setLatLng([lat, lng]);
                circle.setLatLng([lat, lng]);
            }
        });
    </script>
</body>
</html>
