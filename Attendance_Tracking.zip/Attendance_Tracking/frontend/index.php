<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GPS Attendance Tracking System - Home</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .feature-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        .hero-pattern {
            background-color: #667eea;
            background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
        .pulse-animation {
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        @keyframes pulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: .5;
            }
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="container mx-auto px-4 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <div class="bg-indigo-600 p-2 rounded-lg">
                        <i class="fas fa-map-marker-alt text-white text-xl"></i>
                    </div>
                    <span class="text-2xl font-bold text-gray-800">GPS Attendance</span>
                </div>
                <div class="hidden md:flex space-x-6">
                    <a href="#features" class="text-gray-600 hover:text-indigo-600 transition">Features</a>
                    <a href="#how-it-works" class="text-gray-600 hover:text-indigo-600 transition">How It Works</a>
                    <a href="#about" class="text-gray-600 hover:text-indigo-600 transition">About</a>
                </div>
                <div class="flex space-x-3">
                    <a href="login.php" class="px-4 py-2 text-indigo-600 hover:text-indigo-800 font-semibold transition">
                        Login
                    </a>
                    <a href="register.php" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition font-semibold">
                        Get Started
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-pattern text-white py-20">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto text-center">
                <div class="inline-block mb-6">
                    <div class="bg-white bg-opacity-20 backdrop-blur-sm px-4 py-2 rounded-full">
                        <span class="text-sm font-semibold">
                            <i class="fas fa-satellite-dish mr-2 pulse-animation"></i>
                            Real-Time GPS Tracking
                        </span>
                    </div>
                </div>
                <h1 class="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                    Modern Attendance Tracking with GPS Technology
                </h1>
                <p class="text-xl md:text-2xl mb-8 text-indigo-100">
                    Automated, accurate, and secure attendance management powered by geolocation
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="register.php" class="px-8 py-4 bg-white text-indigo-600 rounded-lg font-bold text-lg hover:bg-gray-100 transition shadow-xl">
                        <i class="fas fa-user-plus mr-2"></i>
                        Register Now
                    </a>
                    <a href="login.php" class="px-8 py-4 bg-indigo-800 text-white rounded-lg font-bold text-lg hover:bg-indigo-900 transition shadow-xl">
                        <i class="fas fa-sign-in-alt mr-2"></i>
                        Student Login
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="py-12 bg-white">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <div>
                    <div class="text-4xl font-bold text-indigo-600 mb-2">
                        <i class="fas fa-map-marked-alt"></i>
                    </div>
                    <div class="text-3xl font-bold text-gray-800">GPS</div>
                    <div class="text-gray-600">Tracking</div>
                </div>
                <div>
                    <div class="text-4xl font-bold text-green-600 mb-2">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="text-3xl font-bold text-gray-800">Real-Time</div>
                    <div class="text-gray-600">Updates</div>
                </div>
                <div>
                    <div class="text-4xl font-bold text-purple-600 mb-2">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="text-3xl font-bold text-gray-800">Secure</div>
                    <div class="text-gray-600">System</div>
                </div>
                <div>
                    <div class="text-4xl font-bold text-orange-600 mb-2">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="text-3xl font-bold text-gray-800">Analytics</div>
                    <div class="text-gray-600">Dashboard</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-gray-800 mb-4">Powerful Features</h2>
                <p class="text-xl text-gray-600">Everything you need for modern attendance management</p>
            </div>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <!-- Feature 1 -->
                <div class="feature-card bg-white rounded-xl p-6 shadow-lg">
                    <div class="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                        <i class="fas fa-map-marker-alt text-blue-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">GPS Check-In/Out</h3>
                    <p class="text-gray-600">Automatic location capture when students check in and out of classes with precise GPS coordinates.</p>
                </div>

                <!-- Feature 2 -->
                <div class="feature-card bg-white rounded-xl p-6 shadow-lg">
                    <div class="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                        <i class="fas fa-draw-circle text-green-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Geofence Validation</h3>
                    <p class="text-gray-600">Define virtual boundaries for each class and automatically validate student presence within the area.</p>
                </div>

                <!-- Feature 3 -->
                <div class="feature-card bg-white rounded-xl p-6 shadow-lg">
                    <div class="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                        <i class="fas fa-route text-purple-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Real-Time Tracking</h3>
                    <p class="text-gray-600">Continuous location monitoring while checked in with configurable tracking intervals.</p>
                </div>

                <!-- Feature 4 -->
                <div class="feature-card bg-white rounded-xl p-6 shadow-lg">
                    <div class="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                        <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Violation Detection</h3>
                    <p class="text-gray-600">Automatic detection and logging when students leave the designated geofence area.</p>
                </div>

                <!-- Feature 5 -->
                <div class="feature-card bg-white rounded-xl p-6 shadow-lg">
                    <div class="bg-yellow-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                        <i class="fas fa-chart-bar text-yellow-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Admin Dashboard</h3>
                    <p class="text-gray-600">Comprehensive analytics, reports, and visualization tools for administrators.</p>
                </div>

                <!-- Feature 6 -->
                <div class="feature-card bg-white rounded-xl p-6 shadow-lg">
                    <div class="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                        <i class="fas fa-history text-indigo-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-bold text-gray-800 mb-3">Attendance History</h3>
                    <p class="text-gray-600">Complete attendance records with map visualization and CSV export capabilities.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section id="how-it-works" class="py-20 bg-white">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-gray-800 mb-4">How It Works</h2>
                <p class="text-xl text-gray-600">Simple and efficient attendance tracking in 3 steps</p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div class="grid md:grid-cols-3 gap-8">
                    <!-- Step 1 -->
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-indigo-500 to-purple-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold shadow-lg">
                            1
                        </div>
                        <h3 class="text-xl font-bold text-gray-800 mb-3">Register</h3>
                        <p class="text-gray-600">Create your student account with your unique Student ID and personal information.</p>
                    </div>

                    <!-- Step 2 -->
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-green-500 to-teal-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold shadow-lg">
                            2
                        </div>
                        <h3 class="text-xl font-bold text-gray-800 mb-3">Check In</h3>
                        <p class="text-gray-600">Use your device's GPS to check in when you arrive at class. Location is automatically verified.</p>
                    </div>

                    <!-- Step 3 -->
                    <div class="text-center">
                        <div class="bg-gradient-to-br from-orange-500 to-red-600 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold shadow-lg">
                            3
                        </div>
                        <h3 class="text-xl font-bold text-gray-800 mb-3">Track & View</h3>
                        <p class="text-gray-600">View your attendance history, tracking data, and statistics on your personal dashboard.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Technology Stack Section -->
    <section class="py-20 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="text-center mb-16">
                <h2 class="text-4xl font-bold text-gray-800 mb-4">Built with Modern Technology</h2>
                <p class="text-xl text-gray-600">Reliable, secure, and scalable architecture</p>
            </div>

            <div class="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
                <!-- Backend -->
                <div class="bg-white rounded-xl p-8 shadow-lg">
                    <div class="flex items-center mb-6">
                        <div class="bg-blue-100 w-12 h-12 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-server text-blue-600 text-xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold text-gray-800">Backend</h3>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-gray-700">
                            <i class="fas fa-check-circle text-green-500 mr-3"></i>
                            Python 3.8+ with Flask
                        </li>
                        <li class="flex items-center text-gray-700">
                            <i class="fas fa-check-circle text-green-500 mr-3"></i>
                            MySQL/MariaDB Database
                        </li>
                        <li class="flex items-center text-gray-700">
                            <i class="fas fa-check-circle text-green-500 mr-3"></i>
                            RESTful API Architecture
                        </li>
                        <li class="flex items-center text-gray-700">
                            <i class="fas fa-check-circle text-green-500 mr-3"></i>
                            CORS Security
                        </li>
                    </ul>
                </div>

                <!-- Frontend -->
                <div class="bg-white rounded-xl p-8 shadow-lg">
                    <div class="flex items-center mb-6">
                        <div class="bg-purple-100 w-12 h-12 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-desktop text-purple-600 text-xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold text-gray-800">Frontend</h3>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-center text-gray-700">
                            <i class="fas fa-check-circle text-green-500 mr-3"></i>
                            PHP 7.4+ Server-Side
                        </li>
                        <li class="flex items-center text-gray-700">
                            <i class="fas fa-check-circle text-green-500 mr-3"></i>
                            Tailwind CSS Styling
                        </li>
                        <li class="flex items-center text-gray-700">
                            <i class="fas fa-check-circle text-green-500 mr-3"></i>
                            Leaflet.js Maps
                        </li>
                        <li class="flex items-center text-gray-700">
                            <i class="fas fa-check-circle text-green-500 mr-3"></i>
                            HTML5 Geolocation API
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-20 bg-white">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto text-center">
                <h2 class="text-4xl font-bold text-gray-800 mb-6">About the System</h2>
                <p class="text-lg text-gray-600 mb-8 leading-relaxed">
                    The GPS Attendance Tracking System is a comprehensive solution designed to modernize attendance management 
                    through location-based technology. By leveraging GPS and geofencing capabilities, the system ensures 
                    accurate, automated, and tamper-proof attendance records while providing real-time insights for 
                    administrators and students alike.
                </p>
                <div class="grid md:grid-cols-3 gap-6 mt-12">
                    <div class="bg-blue-50 rounded-lg p-6">
                        <i class="fas fa-lock text-blue-600 text-3xl mb-3"></i>
                        <h4 class="font-bold text-gray-800 mb-2">Secure</h4>
                        <p class="text-sm text-gray-600">Protected with modern security practices and encrypted data</p>
                    </div>
                    <div class="bg-green-50 rounded-lg p-6">
                        <i class="fas fa-bolt text-green-600 text-3xl mb-3"></i>
                        <h4 class="font-bold text-gray-800 mb-2">Fast</h4>
                        <p class="text-sm text-gray-600">Real-time processing and instant attendance verification</p>
                    </div>
                    <div class="bg-purple-50 rounded-lg p-6">
                        <i class="fas fa-mobile-alt text-purple-600 text-3xl mb-3"></i>
                        <h4 class="font-bold text-gray-800 mb-2">Mobile-Ready</h4>
                        <p class="text-sm text-gray-600">Fully responsive design works on any device</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="gradient-bg text-white py-16">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-4xl font-bold mb-4">Ready to Get Started?</h2>
            <p class="text-xl mb-8 text-indigo-100">Join the modern way of tracking attendance</p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="register.php" class="px-8 py-4 bg-white text-indigo-600 rounded-lg font-bold text-lg hover:bg-gray-100 transition shadow-xl">
                    <i class="fas fa-user-plus mr-2"></i>
                    Register as Student
                </a>
                <a href="login.php" class="px-8 py-4 bg-indigo-800 text-white rounded-lg font-bold text-lg hover:bg-indigo-900 transition shadow-xl border-2 border-white">
                    <i class="fas fa-sign-in-alt mr-2"></i>
                    Login to Dashboard
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-300 py-12">
        <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-4 gap-8">
                <div>
                    <div class="flex items-center space-x-2 mb-4">
                        <div class="bg-indigo-600 p-2 rounded-lg">
                            <i class="fas fa-map-marker-alt text-white"></i>
                        </div>
                        <span class="text-xl font-bold text-white">GPS Attendance</span>
                    </div>
                    <p class="text-sm text-gray-400">Modern attendance tracking powered by GPS technology.</p>
                </div>
                <div>
                    <h4 class="text-white font-bold mb-4">Quick Links</h4>
                    <ul class="space-y-2 text-sm">
                        <li><a href="login.php" class="hover:text-indigo-400 transition">Student Login</a></li>
                        <li><a href="register.php" class="hover:text-indigo-400 transition">Register</a></li>
                        <li><a href="subjects.php" class="hover:text-indigo-400 transition">View Subjects</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-white font-bold mb-4">Features</h4>
                    <ul class="space-y-2 text-sm">
                        <li><i class="fas fa-check text-indigo-400 mr-2"></i>GPS Tracking</li>
                        <li><i class="fas fa-check text-indigo-400 mr-2"></i>Geofence Validation</li>
                        <li><i class="fas fa-check text-indigo-400 mr-2"></i>Real-Time Updates</li>
                        <li><i class="fas fa-check text-indigo-400 mr-2"></i>Analytics Dashboard</li>
                    </ul>
                </div>
                <div>
                    <h4 class="text-white font-bold mb-4">System Status</h4>
                    <div class="space-y-2 text-sm">
                        <div class="flex items-center">
                            <div class="w-2 h-2 bg-green-500 rounded-full mr-2 pulse-animation"></div>
                            <span>System Online</span>
                        </div>
                        <div class="flex items-center">
                            <div class="w-2 h-2 bg-green-500 rounded-full mr-2 pulse-animation"></div>
                            <span>Database Connected</span>
                        </div>
                        <div class="flex items-center">
                            <div class="w-2 h-2 bg-green-500 rounded-full mr-2 pulse-animation"></div>
                            <span>API Active</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
                <p>&copy; 2025 GPS Attendance Tracking System. All rights reserved.</p>
            </div>
        </div>
    </footer>
</body>
</html>
