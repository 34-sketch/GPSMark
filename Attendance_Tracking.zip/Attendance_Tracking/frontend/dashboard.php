<?php
require_once 'config.php';

// Check if logged in
if (!isLoggedIn()) {
    redirect('login.php');
}

$student = getCurrentStudent();

// Get subjects enrolled by this student
$subjectsResponse = apiRequest('/enrollments?student_id=' . urlencode($student['student_id']));
$subjects = $subjectsResponse['data']['enrollments'] ?? [];

// Get active attendance
$activeResponse = apiRequest('/attendance/active?student_id=' . urlencode($student['student_id']));
$activeAttendance = $activeResponse['data']['active_attendance'] ?? [];

// Get attendance statistics
$statsResponse = apiRequest('/attendance/statistics?student_id=' . urlencode($student['student_id']));
$statistics = $statsResponse['data']['statistics'] ?? [
    'total' => 0,
    'present' => 0,
    'late' => 0,
    'absent' => 0,
    'early_checkout' => 0,
    'geofence_violations' => 0
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - GPS Attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        .map-container { height: 300px; border-radius: 0.5rem; }
        .pulse { animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite; }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: .5; }
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-indigo-600 text-white shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-map-marker-alt text-2xl"></i>
                    <div>
                        <h1 class="text-xl font-bold">GPS Attendance</h1>
                        <p class="text-sm text-indigo-200"><?= h($student['full_name']) ?></p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="history.php" class="hover:text-indigo-200">
                        <i class="fas fa-history mr-1"></i> History
                    </a>
                    <a href="logout.php" class="hover:text-indigo-200">
                        <i class="fas fa-sign-out-alt mr-1"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <!-- Student Info -->
        <div class="bg-white rounded-lg shadow-md p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-bold text-gray-800"><?= h($student['full_name']) ?></h2>
                    <p class="text-gray-600">
                        <i class="fas fa-id-card mr-1"></i> <?= h($student['student_id']) ?>
                        <?php if (!empty($student['program_or_grade'])): ?>
                            <span class="ml-3">
                                <i class="fas fa-graduation-cap mr-1"></i> <?= h($student['program_or_grade']) ?>
                            </span>
                        <?php endif; ?>
                    </p>
                </div>
                <div class="text-right">
                    <div id="currentTime" class="text-2xl font-bold text-indigo-600"></div>
                    <div id="currentDate" class="text-sm text-gray-600"></div>
                </div>
            </div>
        </div>

        <!-- Attendance Statistics Header -->
        <div class="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg shadow-lg p-6 mb-4 text-white">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-bold mb-2">
                        <i class="fas fa-chart-pie mr-2"></i>
                        Your Attendance Statistics
                    </h2>
                    <p class="text-indigo-100">Track your attendance performance at a glance</p>
                    <a href="history.php" class="inline-block mt-2 text-sm text-indigo-200 hover:text-white transition">
                        <i class="fas fa-history mr-1"></i> View Full History
                    </a>
                </div>
                <div class="text-right">
                    <?php if ($statistics['total'] > 0): ?>
                        <?php 
                        $attendanceRate = round((($statistics['present'] + $statistics['late']) / $statistics['total']) * 100, 1);
                        $rateColor = $attendanceRate >= 90 ? 'text-green-300' : ($attendanceRate >= 75 ? 'text-yellow-300' : 'text-red-300');
                        ?>
                        <div class="text-4xl font-bold <?= $rateColor ?>"><?= $attendanceRate ?>%</div>
                        <div class="text-sm text-indigo-200">Attendance Rate</div>
                    <?php else: ?>
                        <div class="text-4xl font-bold">--</div>
                        <div class="text-sm text-indigo-200">No records yet</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Attendance Statistics Cards -->
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
            <!-- Total Records -->
            <div class="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition">
                <div class="flex items-center justify-between mb-2">
                    <div class="bg-blue-100 p-3 rounded-lg">
                        <i class="fas fa-calendar-check text-blue-600 text-xl"></i>
                    </div>
                </div>
                <div class="text-2xl font-bold text-gray-800"><?= $statistics['total'] ?></div>
                <div class="text-sm text-gray-600">Total Records</div>
            </div>

            <!-- Present -->
            <div class="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition">
                <div class="flex items-center justify-between mb-2">
                    <div class="bg-green-100 p-3 rounded-lg">
                        <i class="fas fa-check-circle text-green-600 text-xl"></i>
                    </div>
                </div>
                <div class="text-2xl font-bold text-green-600"><?= $statistics['present'] ?></div>
                <div class="text-sm text-gray-600">Present</div>
                <?php if ($statistics['total'] > 0): ?>
                    <div class="text-xs text-gray-500 mt-1">
                        <?= round(($statistics['present'] / $statistics['total']) * 100, 1) ?>%
                    </div>
                <?php endif; ?>
            </div>

            <!-- Late -->
            <div class="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition">
                <div class="flex items-center justify-between mb-2">
                    <div class="bg-yellow-100 p-3 rounded-lg">
                        <i class="fas fa-clock text-yellow-600 text-xl"></i>
                    </div>
                </div>
                <div class="text-2xl font-bold text-yellow-600"><?= $statistics['late'] ?></div>
                <div class="text-sm text-gray-600">Late</div>
                <?php if ($statistics['total'] > 0): ?>
                    <div class="text-xs text-gray-500 mt-1">
                        <?= round(($statistics['late'] / $statistics['total']) * 100, 1) ?>%
                    </div>
                <?php endif; ?>
            </div>

            <!-- Absent -->
            <div class="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition">
                <div class="flex items-center justify-between mb-2">
                    <div class="bg-red-100 p-3 rounded-lg">
                        <i class="fas fa-times-circle text-red-600 text-xl"></i>
                    </div>
                </div>
                <div class="text-2xl font-bold text-red-600"><?= $statistics['absent'] ?></div>
                <div class="text-sm text-gray-600">Absent</div>
                <?php if ($statistics['total'] > 0): ?>
                    <div class="text-xs text-gray-500 mt-1">
                        <?= round(($statistics['absent'] / $statistics['total']) * 100, 1) ?>%
                    </div>
                <?php endif; ?>
            </div>

            <!-- Early Checkout -->
            <div class="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition">
                <div class="flex items-center justify-between mb-2">
                    <div class="bg-orange-100 p-3 rounded-lg">
                        <i class="fas fa-door-open text-orange-600 text-xl"></i>
                    </div>
                </div>
                <div class="text-2xl font-bold text-orange-600"><?= $statistics['early_checkout'] ?></div>
                <div class="text-sm text-gray-600">Early Checkout</div>
                <?php if ($statistics['total'] > 0): ?>
                    <div class="text-xs text-gray-500 mt-1">
                        <?= round(($statistics['early_checkout'] / $statistics['total']) * 100, 1) ?>%
                    </div>
                <?php endif; ?>
            </div>

            <!-- Geofence Violations -->
            <div class="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition">
                <div class="flex items-center justify-between mb-2">
                    <div class="bg-purple-100 p-3 rounded-lg">
                        <i class="fas fa-exclamation-triangle text-purple-600 text-xl"></i>
                    </div>
                </div>
                <div class="text-2xl font-bold text-purple-600"><?= $statistics['geofence_violations'] ?></div>
                <div class="text-sm text-gray-600">Violations</div>
                <?php if ($statistics['total'] > 0): ?>
                    <div class="text-xs text-gray-500 mt-1">
                        <?= round(($statistics['geofence_violations'] / $statistics['total']) * 100, 1) ?>%
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Active Attendance Alert -->
        <?php if (!empty($activeAttendance)): ?>
            <div class="bg-green-50 border-l-4 border-green-500 p-6 mb-6 rounded-lg shadow-md">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-lg font-bold text-green-800 mb-2">
                            <i class="fas fa-check-circle mr-2 pulse"></i>
                            Currently Checked In
                        </h3>
                        <?php foreach ($activeAttendance as $att): ?>
                            <div class="mb-4 last:mb-0">
                                <p class="text-green-700 font-semibold"><?= h($att['subject_title']) ?></p>
                                <p class="text-sm text-green-600">
                                    <i class="fas fa-clock mr-1"></i> 
                                    Checked in at <?php
                                        // Handle both datetime object and formatted string
                                        $time = $att['check_in_time'];
                                        if (preg_match('/\d{1,2}:\d{2} (AM|PM)/', $time)) {
                                            // Already formatted (e.g., "2025-10-10 07:44:29 PM")
                                            echo preg_replace('/.*(\d{1,2}:\d{2}:\d{2} (AM|PM))/', '$1', $time);
                                        } else {
                                            // Need to format
                                            echo date('g:i A', strtotime($time));
                                        }
                                    ?>
                                </p>
                                <p class="text-sm text-green-600">
                                    <i class="fas fa-map-pin mr-1"></i> 
                                    <?= h($att['location_name']) ?>
                                </p>
                                <?php if ($att['warning_out_of_radius']): ?>
                                    <p class="text-sm text-red-600 font-semibold mt-1">
                                        <i class="fas fa-exclamation-triangle mr-1"></i>
                                        Warning: You went outside the geofence area
                                    </p>
                                <?php endif; ?>
                                <button onclick="checkOut('<?= h($att['attendance_id']) ?>')" 
                                        class="mt-3 bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition">
                                    <i class="fas fa-sign-out-alt mr-2"></i>
                                    Check Out
                                </button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div id="trackingStatus" class="text-right">
                        <div class="inline-block px-4 py-2 bg-green-100 rounded-lg">
                            <i class="fas fa-satellite-dish text-green-600 text-2xl pulse"></i>
                            <p class="text-xs text-green-700 mt-1">Tracking Active</p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Real-Time Location Status -->
        <div id="locationStatus" class="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6 hidden">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <i class="fas fa-satellite-dish text-blue-600 text-xl mr-3 animate-pulse"></i>
                    <div>
                        <p class="font-semibold text-blue-800">🌍 Real-Time Location Tracking Active</p>
                        <p id="locationCoords" class="text-sm text-blue-600">Detecting...</p>
                    </div>
                </div>
                <div class="text-right">
                    <div id="locationAccuracy" class="text-sm text-blue-600"></div>
                    <div id="geofenceStatus" class="mt-1"></div>
                </div>
            </div>
        </div>

        <!-- Geofence Warning -->
        <div id="geofenceWarning" class="bg-red-50 border-l-4 border-red-500 p-4 mb-6 rounded-lg shadow-md hidden animate-pulse">
            <div class="flex items-center">
                <i class="fas fa-exclamation-triangle text-red-600 text-2xl mr-3"></i>
                <div>
                    <h3 class="font-bold text-red-800">⚠️ Outside Campus Radius ❌</h3>
                    <p class="text-red-700 text-sm font-semibold">You are outside the allowed area! Please return to the class location immediately.</p>
                    <p id="warningDistance" class="text-red-600 text-xs mt-1 font-semibold"></p>
                </div>
            </div>
        </div>

        <!-- Geofence Valid Status -->
        <div id="geofenceValid" class="bg-green-50 border-l-4 border-green-500 p-4 mb-6 rounded-lg shadow-md hidden">
            <div class="flex items-center">
                <i class="fas fa-check-circle text-green-600 text-2xl mr-3"></i>
                <div>
                    <h3 class="font-bold text-green-800">✅ Inside Campus Radius</h3>
                    <p class="text-green-700 text-sm">Location verified. You are within the allowed area.</p>
                </div>
            </div>
        </div>

        <!-- Available Subjects -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-4">
                <i class="fas fa-book mr-2"></i>
                Available Subjects
            </h2>

            <?php if (empty($subjects)): ?>
                <p class="text-gray-600 text-center py-8">
                    <i class="fas fa-info-circle mr-2"></i>
                    No subjects available at the moment.
                </p>
            <?php else: ?>
                <div class="grid md:grid-cols-2 gap-4">
                    <?php foreach ($subjects as $subject): ?>
                        <div class="border border-gray-200 rounded-lg p-4 hover:shadow-lg transition">
                            <h3 class="font-bold text-lg text-gray-800 mb-2"><?= h($subject['title']) ?></h3>
                            
                            <div class="space-y-1 text-sm text-gray-600 mb-3">
                                <?php if (!empty($subject['instructor'])): ?>
                                    <p><i class="fas fa-chalkboard-teacher mr-2 w-4"></i> <?= h($subject['instructor']) ?></p>
                                <?php endif; ?>
                                
                                <?php if (!empty($subject['location_name'])): ?>
                                    <p><i class="fas fa-map-marker-alt mr-2 w-4"></i> <?= h($subject['location_name']) ?></p>
                                <?php endif; ?>
                                
                                <p><i class="fas fa-calendar-days mr-2 w-4"></i> 
                                    <?php
                                    if (!empty($subject['scheduled_days'])) {
                                        // Convert abbreviated days to full names
                                        $days = explode(',', $subject['scheduled_days']);
                                        $dayNames = [
                                            'Mon' => 'Monday',
                                            'Tue' => 'Tuesday', 
                                            'Wed' => 'Wednesday',
                                            'Thu' => 'Thursday',
                                            'Fri' => 'Friday',
                                            'Sat' => 'Saturday',
                                            'Sun' => 'Sunday'
                                        ];
                                        $fullDays = array_map(function($day) use ($dayNames) {
                                            return $dayNames[trim($day)] ?? trim($day);
                                        }, $days);
                                        echo implode(', ', $fullDays);
                                    } else {
                                        echo 'Every day';
                                    }
                                    ?>
                                </p>
                                
                                <?php if ($subject['scheduled_start']): ?>
                                    <p><i class="fas fa-clock mr-2 w-4"></i> 
                                        <?= date('g:i A', strtotime($subject['scheduled_start'])) ?> - 
                                        <?= date('g:i A', strtotime($subject['scheduled_end'])) ?>
                                    </p>
                                <?php endif; ?>
                                
                                <p><i class="fas fa-circle-notch mr-2 w-4"></i> 
                                    Radius: <?= h($subject['geofence_radius_meters']) ?>m
                                </p>
                            </div>

                            <!-- Map Preview -->
                            <div id="map-<?= h($subject['subject_id']) ?>" class="map-container mb-3"></div>

                            <button onclick="checkIn('<?= h($subject['subject_id']) ?>', <?= $subject['geofence_center_lat'] ?>, <?= $subject['geofence_center_lng'] ?>, <?= $subject['geofence_radius_meters'] ?>)" 
                                    class="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition font-semibold"
                                    id="btn-<?= h($subject['subject_id']) ?>">
                                <i class="fas fa-sign-in-alt mr-2"></i>
                                Check In
                            </button>
                        </div>

                        <script>
                            // Initialize map for this subject
                            (function() {
                                const map = L.map('map-<?= h($subject['subject_id']) ?>', {
                                    center: [<?= $subject['geofence_center_lat'] ?>, <?= $subject['geofence_center_lng'] ?>],
                                    zoom: 17,
                                    zoomControl: false,
                                    dragging: false,
                                    scrollWheelZoom: false
                                });

                                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                    attribution: '© OpenStreetMap'
                                }).addTo(map);

                                // Add geofence circle
                                L.circle([<?= $subject['geofence_center_lat'] ?>, <?= $subject['geofence_center_lng'] ?>], {
                                    radius: <?= $subject['geofence_radius_meters'] ?>,
                                    color: '#4f46e5',
                                    fillColor: '#818cf8',
                                    fillOpacity: 0.2
                                }).addTo(map);

                                // Add marker
                                L.marker([<?= $subject['geofence_center_lat'] ?>, <?= $subject['geofence_center_lng'] ?>])
                                    .addTo(map)
                                    .bindPopup('<?= h($subject['location_name']) ?>');
                            })();
                        </script>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- JavaScript for GPS Tracking -->
    <script src="js/gps-tracker.js"></script>
    <script>
        const API_BASE_URL = '<?= API_BASE_URL ?>';
        const STUDENT_ID = '<?= h($student['student_id']) ?>';
        const TRACKING_INTERVAL = <?= TRACKING_INTERVAL_MS ?>;
        const activeAttendance = <?= json_encode($activeAttendance) ?>;

        // Update time
        function updateTime() {
            const now = new Date();
            document.getElementById('currentTime').textContent = now.toLocaleTimeString();
            document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', {
                weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
            });
        }
        updateTime();
        setInterval(updateTime, 1000);

        // Initialize GPS tracker
        const tracker = new GPSTracker({
            apiBaseUrl: API_BASE_URL,
            studentId: STUDENT_ID,
            trackingInterval: TRACKING_INTERVAL,
            onLocationUpdate: (position) => {
                const status = document.getElementById('locationStatus');
                status.classList.remove('hidden');
                document.getElementById('locationCoords').textContent = 
                    `Lat: ${position.coords.latitude.toFixed(6)}, Lng: ${position.coords.longitude.toFixed(6)}`;
                document.getElementById('locationAccuracy').textContent = 
                    `Accuracy: ±${Math.round(position.coords.accuracy)}m`;
                
                // Update timestamp
                const now = new Date();
                const timeStr = now.toLocaleTimeString();
                document.getElementById('geofenceStatus').innerHTML = 
                    `<span class="text-xs text-gray-500">Updated: ${timeStr}</span>`;
            },
            onGeofenceViolation: (data) => {
                // Show warning
                const warning = document.getElementById('geofenceWarning');
                warning.classList.remove('hidden');
                document.getElementById('warningDistance').textContent = 
                    `Distance from center: ${Math.round(data.distance_from_center)}m (Max allowed: ${data.allowed_radius}m)`;
                
                // Hide valid status
                document.getElementById('geofenceValid').classList.add('hidden');
                
                // Update geofence status indicator
                document.getElementById('geofenceStatus').innerHTML = 
                    `<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-800">
                        <span class="w-2 h-2 bg-red-500 rounded-full mr-1 animate-pulse"></span>
                        Outside Radius ❌
                    </span>`;
            },
            onGeofenceValid: () => {
                // Hide warning
                document.getElementById('geofenceWarning').classList.add('hidden');
                
                // Show valid status
                const validStatus = document.getElementById('geofenceValid');
                validStatus.classList.remove('hidden');
                
                // Update geofence status indicator
                document.getElementById('geofenceStatus').innerHTML = 
                    `<span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                        <span class="w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse"></span>
                        Inside Radius ✅
                    </span>`;
            }
        });

        // Start tracking if already checked in
        if (activeAttendance.length > 0) {
            activeAttendance.forEach(att => {
                tracker.startTracking(att.attendance_id, {
                    lat: att.geofence_center_lat,
                    lng: att.geofence_center_lng,
                    radius: att.geofence_radius_meters
                });
            });
        }

        // Check in function
        async function checkIn(subjectId, centerLat, centerLng, radius) {
            const btn = document.getElementById(`btn-${subjectId}`);
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Checking location...';

            try {
                const result = await tracker.checkIn(subjectId);
                if (result.success) {
                    alert('Check-in successful!');
                    location.reload();
                } else {
                    alert(result.error || 'Check-in failed');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-sign-in-alt mr-2"></i> Check In';
                }
            } catch (error) {
                alert('Error: ' + error.message);
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-sign-in-alt mr-2"></i> Check In';
            }
        }

        // Check out function with early checkout handling
        async function checkOut(attendanceId) {
            const btn = event.target;
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Processing...';
            
            try {
                console.log('Attempting checkout for:', attendanceId);
                
                // First attempt without reason
                const result = await tracker.checkOut(attendanceId);
                console.log('Checkout result:', result);
                
                if (result.success) {
                    alert('✅ Check-out successful!');
                    location.reload();
                } else if (result.requires_reason) {
                    console.log('Early checkout detected, showing dialog');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-sign-out-alt mr-2"></i> Check Out';
                    
                    // Early checkout detected - show reason dialog
                    const info = result.early_checkout_info;
                    const minutesEarly = info.minutes_early || 0;
                    
                    // Show custom dialog with reason options
                    const reason = await showEarlyCheckoutDialog(minutesEarly, info.scheduled_end);
                    console.log('Selected reason:', reason);
                    
                    if (reason) {
                        // Retry checkout with reason
                        btn.disabled = true;
                        btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Processing...';
                        console.log('Retrying checkout with reason:', reason);
                        const retryResult = await tracker.checkOut(attendanceId, reason);
                        console.log('Retry result:', retryResult);
                        
                        if (retryResult.success) {
                            alert('✅ Early checkout approved!\nReason: ' + reason);
                            location.reload();
                        } else {
                            alert('❌ ' + (retryResult.error || 'Check-out failed'));
                            btn.disabled = false;
                            btn.innerHTML = '<i class="fas fa-sign-out-alt mr-2"></i> Check Out';
                        }
                    } else {
                        console.log('User cancelled early checkout');
                    }
                } else {
                    console.error('Checkout failed:', result.error);
                    let errorMsg = result.error || 'Check-out failed';
                    if (errorMsg.includes('Location request timed out')) {
                        errorMsg += '\n\n💡 Tips:\n- Make sure GPS/Location is enabled\n- Try moving to an open area\n- Check if location permission is granted\n- Wait a moment and try again';
                    }
                    alert('❌ ' + errorMsg);
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-sign-out-alt mr-2"></i> Check Out';
                }
            } catch (error) {
                console.error('Checkout error:', error);
                let errorMsg = error.message;
                if (errorMsg.includes('Location request timed out') || errorMsg.includes('location')) {
                    errorMsg += '\n\n💡 Tips:\n- Make sure GPS/Location is enabled\n- Try moving to an open area\n- Check if location permission is granted\n- Wait a moment and try again';
                }
                alert('❌ Error: ' + errorMsg);
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-sign-out-alt mr-2"></i> Check Out';
            }
        }

        // Show early checkout dialog
        function showEarlyCheckoutDialog(minutesEarly, scheduledEnd) {
            return new Promise((resolve) => {
                // Create modal
                const modal = document.createElement('div');
                modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
                modal.innerHTML = `
                    <div class="bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6">
                        <div class="text-center mb-4">
                            <i class="fas fa-exclamation-triangle text-yellow-500 text-5xl mb-3"></i>
                            <h2 class="text-2xl font-bold text-gray-800">Early Checkout</h2>
                        </div>
                        
                        <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 mb-4">
                            <p class="text-sm text-yellow-800">
                                <strong>Scheduled End:</strong> ${scheduledEnd}<br>
                                <strong>Early by:</strong> ${minutesEarly} minutes
                            </p>
                        </div>
                        
                        <p class="text-gray-700 mb-4">
                            The subject is not yet finished. Please provide a reason for early checkout:
                        </p>
                        
                        <div class="space-y-2 mb-4">
                            <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="reason" value="Emergency" class="mr-3">
                                <span class="text-gray-800">🚨 Emergency</span>
                            </label>
                            <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="reason" value="Sick" class="mr-3">
                                <span class="text-gray-800">🤒 Feeling Sick</span>
                            </label>
                            <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="reason" value="Class dismissed early" class="mr-3">
                                <span class="text-gray-800">✅ Class Dismissed Early</span>
                            </label>
                            <label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                                <input type="radio" name="reason" value="Other" class="mr-3">
                                <span class="text-gray-800">📝 Other</span>
                            </label>
                        </div>
                        
                        <div id="otherReasonDiv" class="mb-4 hidden">
                            <input type="text" id="otherReasonInput" placeholder="Please specify..." 
                                   class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                        </div>
                        
                        <div class="flex space-x-3">
                            <button id="cancelBtn" class="flex-1 bg-gray-300 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-400 font-semibold">
                                Cancel
                            </button>
                            <button id="confirmBtn" class="flex-1 bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 font-semibold">
                                Confirm Checkout
                            </button>
                        </div>
                    </div>
                `;
                
                document.body.appendChild(modal);
                
                // Handle "Other" option
                const radios = modal.querySelectorAll('input[name="reason"]');
                const otherDiv = modal.querySelector('#otherReasonDiv');
                const otherInput = modal.querySelector('#otherReasonInput');
                
                radios.forEach(radio => {
                    radio.addEventListener('change', (e) => {
                        if (e.target.value === 'Other') {
                            otherDiv.classList.remove('hidden');
                            otherInput.focus();
                        } else {
                            otherDiv.classList.add('hidden');
                        }
                    });
                });
                
                // Handle confirm
                modal.querySelector('#confirmBtn').addEventListener('click', () => {
                    const selected = modal.querySelector('input[name="reason"]:checked');
                    if (selected) {
                        let reason = selected.value;
                        if (reason === 'Other') {
                            const otherText = otherInput.value.trim();
                            if (otherText) {
                                reason = 'Other: ' + otherText;
                            } else {
                                alert('Please specify the reason');
                                return;
                            }
                        }
                        document.body.removeChild(modal);
                        resolve(reason);
                    } else {
                        alert('Please select a reason');
                    }
                });
                
                // Handle cancel
                modal.querySelector('#cancelBtn').addEventListener('click', () => {
                    document.body.removeChild(modal);
                    resolve(null);
                });
            });
        }
    </script>
</body>
</html>
