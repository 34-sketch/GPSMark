"""
GPS Attendance Tracking System - Python Backend API
Flask REST API with geofence validation and real-time tracking
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
from mysql.connector import Error
import os
from datetime import datetime, timedelta
import pytz
import uuid
import math
from functools import wraps
import json

app = Flask(__name__)
CORS(app)  # Enable CORS for PHP frontend

# Timezone configuration - Philippine Time
TIMEZONE = pytz.timezone('Asia/Manila')

# Database configuration
DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'user': os.getenv('DB_USER', 'root'),
    'password': os.getenv('DB_PASSWORD', ''),
    'database': os.getenv('DB_NAME', 'gps_attendance'),
    'charset': 'utf8mb4',
    'collation': 'utf8mb4_unicode_ci'
}

# Configuration
TRACKING_INTERVAL_SECONDS = int(os.getenv('TRACKING_INTERVAL', 10))  # Default 10 seconds


def get_current_time():
    """Get current time in Philippine timezone (naive datetime for MySQL compatibility)"""
    # Get timezone-aware datetime, then convert to naive for MySQL DATETIME compatibility
    return datetime.now(TIMEZONE).replace(tzinfo=None)


def get_db_connection():
    """Create and return a database connection"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except Error as e:
        print(f"Database connection error: {e}")
        return None


def haversine_distance(lat1, lon1, lat2, lon2):
    """
    Calculate the great circle distance between two points 
    on the earth (specified in decimal degrees)
    Returns distance in meters
    """
    # Convert decimal degrees to radians
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])
    
    # Haversine formula
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
    c = 2 * math.asin(math.sqrt(a))
    
    # Radius of earth in meters
    r = 6371000
    return c * r


def validate_geofence(lat, lng, center_lat, center_lng, radius_meters):
    """
    Validate if a location is within the geofence
    Returns (is_valid, distance)
    """
    distance = haversine_distance(lat, lng, center_lat, center_lng)
    is_valid = distance <= radius_meters
    return is_valid, distance


def format_datetime_fields(data):
    """Convert datetime objects to Philippine time strings"""
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, datetime):
                data[key] = value.strftime('%Y-%m-%d %I:%M:%S %p')
            elif isinstance(value, list):
                data[key] = [format_datetime_fields(item) if isinstance(item, dict) else item for item in value]
            elif isinstance(value, dict):
                data[key] = format_datetime_fields(value)
    return data


def json_response(data, status=200):
    """Helper to create JSON responses with proper datetime formatting"""
    # Format datetime objects before jsonifying
    formatted_data = format_datetime_fields(data.copy() if isinstance(data, dict) else data)
    response = jsonify(formatted_data)
    response.status_code = status
    return response


def validate_required_fields(data, required_fields):
    """Validate that all required fields are present"""
    missing = [field for field in required_fields if field not in data or not data[field]]
    if missing:
        return False, f"Missing required fields: {', '.join(missing)}"
    return True, None


def serialize_record(record):
    """Convert database record to JSON-serializable format"""
    if not record:
        return record
    
    from decimal import Decimal
    
    for key, value in record.items():
        # Convert Decimal to float
        if isinstance(value, Decimal):
            record[key] = float(value)
        # Convert timedelta to string (HH:MM:SS)
        elif isinstance(value, timedelta):
            total_seconds = int(value.total_seconds())
            hours = total_seconds // 3600
            minutes = (total_seconds % 3600) // 60
            seconds = total_seconds % 60
            record[key] = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        # Convert datetime to ISO format string
        elif isinstance(value, datetime):
            record[key] = value.isoformat()
    
    return record


# ==================== STUDENT ENDPOINTS ====================

@app.route('/api/students', methods=['GET'])
def get_students():
    """Get all students or search by student_id"""
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        student_id = request.args.get('student_id')
        
        if student_id:
            cursor.execute("SELECT * FROM students WHERE student_id = %s", (student_id,))
            student = cursor.fetchone()
            if student:
                return json_response({'success': True, 'student': student})
            else:
                return json_response({'error': 'Student not found'}, 404)
        else:
            cursor.execute("SELECT * FROM students ORDER BY created_at DESC")
            students = cursor.fetchall()
            return json_response({'success': True, 'students': students})
    
    except Error as e:
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/students', methods=['POST'])
def create_student():
    """Register a new student"""
    data = request.get_json()
    
    # Validate required fields
    valid, error = validate_required_fields(data, ['student_id', 'full_name'])
    if not valid:
        return json_response({'error': error}, 400)
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor()
        
        # Check if student_id already exists
        cursor.execute("SELECT id FROM students WHERE student_id = %s", (data['student_id'],))
        if cursor.fetchone():
            return json_response({'error': 'Student ID already exists'}, 409)
        
        # Insert new student
        query = """
            INSERT INTO students (student_id, full_name, program_or_grade, email, phone)
            VALUES (%s, %s, %s, %s, %s)
        """
        values = (
            data['student_id'],
            data['full_name'],
            data.get('program_or_grade', ''),
            data.get('email', ''),
            data.get('phone', '')
        )
        
        cursor.execute(query, values)
        conn.commit()
        
        return json_response({
            'success': True,
            'message': 'Student registered successfully',
            'student_id': data['student_id']
        }, 201)
    
    except Error as e:
        conn.rollback()
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/students/<student_id>', methods=['PUT'])
def update_student(student_id):
    """Update student information"""
    data = request.get_json()
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor()
        
        # Build dynamic update query
        update_fields = []
        values = []
        
        for field in ['full_name', 'program_or_grade', 'email', 'phone']:
            if field in data:
                update_fields.append(f"{field} = %s")
                values.append(data[field])
        
        if not update_fields:
            return json_response({'error': 'No fields to update'}, 400)
        
        values.append(student_id)
        query = f"UPDATE students SET {', '.join(update_fields)} WHERE student_id = %s"
        
        cursor.execute(query, values)
        conn.commit()
        
        if cursor.rowcount == 0:
            return json_response({'error': 'Student not found'}, 404)
        
        return json_response({
            'success': True,
            'message': 'Student updated successfully'
        })
    
    except Error as e:
        conn.rollback()
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


# ==================== SUBJECT ENDPOINTS ====================

@app.route('/api/subjects', methods=['GET'])
def get_subjects():
    """Get all subjects or a specific subject"""
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        subject_id = request.args.get('subject_id')
        
        if subject_id:
            cursor.execute("SELECT * FROM subjects WHERE subject_id = %s", (subject_id,))
            subject = cursor.fetchone()
            if subject:
                subject = serialize_record(subject)
                return json_response({'success': True, 'subject': subject})
            else:
                return json_response({'error': 'Subject not found'}, 404)
        else:
            cursor.execute("SELECT * FROM subjects ORDER BY scheduled_start")
            subjects = cursor.fetchall()
            # Serialize all records
            subjects = [serialize_record(subject) for subject in subjects]
            return json_response({'success': True, 'subjects': subjects})
    
    except Error as e:
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/subjects', methods=['POST'])
def create_subject():
    """Create a new subject/class"""
    data = request.get_json()
    
    # Validate required fields
    required = ['subject_id', 'title', 'geofence_center_lat', 'geofence_center_lng', 'geofence_radius_meters']
    valid, error = validate_required_fields(data, required)
    if not valid:
        return json_response({'error': error}, 400)
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor()
        
        # Check if subject_id already exists
        cursor.execute("SELECT id FROM subjects WHERE subject_id = %s", (data['subject_id'],))
        if cursor.fetchone():
            return json_response({'error': 'Subject ID already exists'}, 409)
        
        # Insert new subject
        query = """
            INSERT INTO subjects 
            (subject_id, title, instructor, location_name, scheduled_start, scheduled_end, scheduled_days,
             geofence_center_lat, geofence_center_lng, geofence_radius_meters)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (
            data['subject_id'],
            data['title'],
            data.get('instructor', ''),
            data.get('location_name', ''),
            data.get('scheduled_start'),
            data.get('scheduled_end'),
            data.get('scheduled_days', 'Mon,Tue,Wed,Thu,Fri,Sat,Sun'),
            data['geofence_center_lat'],
            data['geofence_center_lng'],
            data['geofence_radius_meters']
        )
        
        cursor.execute(query, values)
        conn.commit()
        
        return json_response({
            'success': True,
            'message': 'Subject created successfully',
            'subject_id': data['subject_id']
        }, 201)
    
    except Error as e:
        conn.rollback()
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


# ==================== ATTENDANCE ENDPOINTS ====================

@app.route('/api/attendance/check-in', methods=['POST'])
def check_in():
    """Check in a student for a subject with geofence validation"""
    data = request.get_json()
    
    # Validate required fields
    required = ['student_id', 'subject_id', 'lat', 'lng']
    valid, error = validate_required_fields(data, required)
    if not valid:
        return json_response({'error': error}, 400)
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        # Verify student exists
        cursor.execute("SELECT id FROM students WHERE student_id = %s", (data['student_id'],))
        if not cursor.fetchone():
            return json_response({'error': 'Student not found'}, 404)
        
        # Get subject and geofence info
        cursor.execute("""
            SELECT geofence_center_lat, geofence_center_lng, geofence_radius_meters, title,
                   scheduled_start, scheduled_end, scheduled_days
            FROM subjects WHERE subject_id = %s
        """, (data['subject_id'],))
        subject = cursor.fetchone()
        
        if not subject:
            return json_response({'error': 'Subject not found'}, 404)
        
        # Check if today is a scheduled day for this subject
        if subject['scheduled_days']:
            current_day = get_current_time().strftime('%a')  # Mon, Tue, Wed, Thu, Fri, Sat, Sun
            scheduled_days = subject['scheduled_days'].split(',')
            
            if current_day not in scheduled_days:
                # Get day names for better error message
                day_names = {'Mon': 'Monday', 'Tue': 'Tuesday', 'Wed': 'Wednesday', 
                            'Thu': 'Thursday', 'Fri': 'Friday', 'Sat': 'Saturday', 'Sun': 'Sunday'}
                scheduled_day_names = [day_names.get(day.strip(), day.strip()) for day in scheduled_days]
                
                return json_response({
                    'error': 'Not a scheduled day',
                    'message': f'This subject is only scheduled on: {", ".join(scheduled_day_names)}',
                    'today': day_names.get(current_day, current_day),
                    'scheduled_days': scheduled_day_names
                }, 403)
        
        # Check if student is enrolled in this subject
        cursor.execute("""
            SELECT id FROM student_enrollments 
            WHERE student_id = %s AND subject_id = %s AND status = 'active'
        """, (data['student_id'], data['subject_id']))
        
        if not cursor.fetchone():
            return json_response({'error': 'Student is not enrolled in this subject'}, 403)
        
        # Check if student is already checked in for this subject (not yet checked out)
        cursor.execute("""
            SELECT attendance_id FROM attendance 
            WHERE student_id = %s AND subject_id = %s AND is_checked_out = FALSE
        """, (data['student_id'], data['subject_id']))
        
        if cursor.fetchone():
            return json_response({'error': 'Student is already checked in for this subject'}, 409)
        
        # Check if student already has attendance record for today (prevent double attendance)
        cursor.execute("""
            SELECT attendance_id, check_in_time, is_checked_out 
            FROM attendance 
            WHERE student_id = %s AND subject_id = %s 
            AND DATE(check_in_time) = CURDATE()
        """, (data['student_id'], data['subject_id']))
        
        existing_today = cursor.fetchone()
        if existing_today:
            return json_response({
                'error': 'Already checked in today',
                'message': 'You have already checked in for this subject today. Only one attendance record per day is allowed.',
                'existing_check_in': existing_today['check_in_time'].strftime('%I:%M %p'),
                'is_checked_out': existing_today['is_checked_out']
            }, 409)
        
        # Validate geofence
        is_valid, distance = validate_geofence(
            float(data['lat']),
            float(data['lng']),
            float(subject['geofence_center_lat']),
            float(subject['geofence_center_lng']),
            subject['geofence_radius_meters']
        )
        
        if not is_valid:
            return json_response({
                'error': 'Location is outside the geofence',
                'distance': round(distance, 2),
                'allowed_radius': subject['geofence_radius_meters']
            }, 403)
        
        # Check time-based validation (late/early) and determine attendance status
        check_in_status = 'valid'
        attendance_status = 'present'
        time_status_message = None
        
        if subject['scheduled_start']:
            current_time = get_current_time().time()
            scheduled_start = subject['scheduled_start']
            
            # Convert timedelta to time if needed
            if isinstance(scheduled_start, timedelta):
                total_seconds = int(scheduled_start.total_seconds())
                hours = total_seconds // 3600
                minutes = (total_seconds % 3600) // 60
                seconds = total_seconds % 60
                scheduled_start = datetime.strptime(f"{hours:02d}:{minutes:02d}:{seconds:02d}", "%H:%M:%S").time()
            
            # Calculate 15 minutes before scheduled start (early window)
            early_window = datetime.combine(datetime.today(), scheduled_start) - timedelta(minutes=15)
            early_window_time = early_window.time()
            
            # Calculate 30 minutes after scheduled start (late cutoff)
            late_cutoff = datetime.combine(datetime.today(), scheduled_start) + timedelta(minutes=30)
            late_cutoff_time = late_cutoff.time()
            
            if current_time < early_window_time:
                # Too early - more than 15 minutes before start
                return json_response({
                    'error': 'Check-in too early',
                    'message': f'You can only check in 15 minutes before the scheduled start time ({scheduled_start.strftime("%H:%M")})',
                    'scheduled_start': str(scheduled_start),
                    'earliest_check_in': early_window_time.strftime("%H:%M")
                }, 403)
            elif current_time < scheduled_start:
                # Early but within 15-minute window
                check_in_status = 'valid'
                attendance_status = 'present'
                time_status_message = 'On time (early)'
            elif current_time > late_cutoff_time:
                # Too late - more than 30 minutes after start
                minutes_late = int((datetime.combine(datetime.today(), current_time) - 
                                   datetime.combine(datetime.today(), scheduled_start)).total_seconds() / 60)
                return json_response({
                    'error': 'Check-in too late',
                    'message': f'You cannot check in more than 30 minutes after the scheduled start time ({scheduled_start.strftime("%H:%M")})',
                    'scheduled_start': str(scheduled_start),
                    'late_cutoff': late_cutoff_time.strftime("%H:%M"),
                    'minutes_late': minutes_late
                }, 403)
            elif current_time > scheduled_start:
                # Late but within 30-minute window
                check_in_status = 'warning'
                attendance_status = 'late'
                time_status_message = 'Late'
        
        # Create attendance record
        attendance_id = f"ATT-{uuid.uuid4().hex[:12].upper()}"
        
        query = """
            INSERT INTO attendance 
            (attendance_id, student_id, subject_id, check_in_time, check_in_lat, 
             check_in_lng, check_in_status, attendance_status, is_checked_out)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, FALSE)
        """
        values = (
            attendance_id,
            data['student_id'],
            data['subject_id'],
            get_current_time(),
            data['lat'],
            data['lng'],
            check_in_status,
            attendance_status
        )
        
        cursor.execute(query, values)
        
        # Record initial location tracking
        cursor.execute("""
            INSERT INTO location_tracking 
            (attendance_id, lat, lng, is_within_geofence, distance_from_center)
            VALUES (%s, %s, %s, %s, %s)
        """, (attendance_id, data['lat'], data['lng'], True, round(distance, 2)))
        
        conn.commit()
        
        response_data = {
            'success': True,
            'message': 'Check-in successful',
            'attendance_id': attendance_id,
            'distance_from_center': round(distance, 2),
            'tracking_interval': TRACKING_INTERVAL_SECONDS,
            'check_in_status': check_in_status
        }
        
        if time_status_message:
            response_data['time_status'] = time_status_message
        
        return json_response(response_data, 201)
    
    except Error as e:
        conn.rollback()
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/attendance/check-out', methods=['POST'])
def check_out():
    """Check out a student from a subject with early checkout validation"""
    data = request.get_json()
    
    # Validate required fields
    required = ['attendance_id', 'lat', 'lng']
    valid, error = validate_required_fields(data, required)
    if not valid:
        return json_response({'error': error}, 400)
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        # Get attendance record and subject info
        cursor.execute("""
            SELECT a.*, s.geofence_center_lat, s.geofence_center_lng, s.geofence_radius_meters,
                   s.scheduled_end, s.title as subject_title
            FROM attendance a
            JOIN subjects s ON a.subject_id = s.subject_id
            WHERE a.attendance_id = %s AND a.is_checked_out = FALSE
        """, (data['attendance_id'],))
        
        attendance = cursor.fetchone()
        if not attendance:
            return json_response({'error': 'Attendance record not found or already checked out'}, 404)
        
        # Check if this is an early checkout
        is_early_checkout = False
        scheduled_end = attendance['scheduled_end']
        current_time = get_current_time().time()
        
        if scheduled_end:
            # Convert timedelta to time if needed
            if isinstance(scheduled_end, timedelta):
                total_seconds = int(scheduled_end.total_seconds())
                hours = total_seconds // 3600
                minutes = (total_seconds % 3600) // 60
                seconds = total_seconds % 60
                scheduled_end = datetime.strptime(f"{hours:02d}:{minutes:02d}:{seconds:02d}", "%H:%M:%S").time()
            
            # Check if trying to checkout before scheduled end time
            if current_time < scheduled_end:
                is_early_checkout = True
                
                # If early checkout reason is not provided, require it
                if 'early_checkout_reason' not in data or not data['early_checkout_reason']:
                    minutes_early = int((datetime.combine(datetime.today(), scheduled_end) - 
                                       datetime.combine(datetime.today(), current_time)).total_seconds() / 60)
                    return json_response({
                        'error': 'Early checkout requires a reason',
                        'is_early_checkout': True,
                        'scheduled_end': str(scheduled_end),
                        'current_time': str(current_time),
                        'minutes_early': minutes_early,
                        'message': f'Subject is scheduled until {scheduled_end.strftime("%H:%M")}. Please provide a reason for early checkout.',
                        'requires_reason': True
                    }, 403)
        
        # Validate geofence for check-out
        is_valid, distance = validate_geofence(
            float(data['lat']),
            float(data['lng']),
            float(attendance['geofence_center_lat']),
            float(attendance['geofence_center_lng']),
            attendance['geofence_radius_meters']
        )
        
        check_out_status = 'valid' if is_valid else 'out_of_range'
        
        # Determine final attendance status
        final_attendance_status = attendance['attendance_status']
        if is_early_checkout:
            final_attendance_status = 'early_checkout'
        
        # Update attendance record with early checkout info
        early_checkout_reason = data.get('early_checkout_reason', None)
        
        cursor.execute("""
            UPDATE attendance 
            SET check_out_time = %s, check_out_lat = %s, check_out_lng = %s,
                check_out_status = %s, is_checked_out = TRUE,
                attendance_status = %s, early_checkout_reason = %s
            WHERE attendance_id = %s
        """, (get_current_time(), data['lat'], data['lng'], check_out_status, 
              final_attendance_status, early_checkout_reason, data['attendance_id']))
        
        # Record final location tracking
        cursor.execute("""
            INSERT INTO location_tracking 
            (attendance_id, lat, lng, is_within_geofence, distance_from_center)
            VALUES (%s, %s, %s, %s, %s)
        """, (data['attendance_id'], data['lat'], data['lng'], is_valid, round(distance, 2)))
        
        conn.commit()
        
        response_data = {
            'success': True,
            'message': 'Check-out successful',
            'check_out_status': check_out_status,
            'attendance_status': final_attendance_status,
            'distance_from_center': round(distance, 2),
            'warning': None if is_valid else 'Checked out outside geofence'
        }
        
        if is_early_checkout:
            response_data['is_early_checkout'] = True
            response_data['early_checkout_reason'] = early_checkout_reason
        
        return json_response(response_data)
    
    except Error as e:
        conn.rollback()
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/attendance/track-location', methods=['POST'])
def track_location():
    """Record periodic location updates while checked in"""
    data = request.get_json()
    
    # Validate required fields
    required = ['attendance_id', 'lat', 'lng']
    valid, error = validate_required_fields(data, required)
    if not valid:
        return json_response({'error': error}, 400)
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        # Get attendance record and subject info
        cursor.execute("""
            SELECT a.*, s.geofence_center_lat, s.geofence_center_lng, s.geofence_radius_meters
            FROM attendance a
            JOIN subjects s ON a.subject_id = s.subject_id
            WHERE a.attendance_id = %s AND a.is_checked_out = FALSE
        """, (data['attendance_id'],))
        
        attendance = cursor.fetchone()
        if not attendance:
            return json_response({'error': 'Attendance record not found or already checked out'}, 404)
        
        # Validate geofence
        is_valid, distance = validate_geofence(
            float(data['lat']),
            float(data['lng']),
            float(attendance['geofence_center_lat']),
            float(attendance['geofence_center_lng']),
            attendance['geofence_radius_meters']
        )
        
        # Record location tracking
        cursor.execute("""
            INSERT INTO location_tracking 
            (attendance_id, lat, lng, is_within_geofence, distance_from_center)
            VALUES (%s, %s, %s, %s, %s)
        """, (data['attendance_id'], data['lat'], data['lng'], is_valid, round(distance, 2)))
        
        # If outside geofence, record violation and update attendance
        if not is_valid:
            cursor.execute("""
                INSERT INTO geofence_violations 
                (attendance_id, student_id, subject_id, violation_lat, violation_lng, distance_from_center)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (data['attendance_id'], attendance['student_id'], attendance['subject_id'],
                  data['lat'], data['lng'], round(distance, 2)))
            
            cursor.execute("""
                UPDATE attendance SET warning_out_of_radius = TRUE
                WHERE attendance_id = %s
            """, (data['attendance_id'],))
        
        conn.commit()
        
        return json_response({
            'success': True,
            'is_within_geofence': is_valid,
            'distance_from_center': round(distance, 2),
            'allowed_radius': attendance['geofence_radius_meters'],
            'warning': None if is_valid else 'You are outside the geofence area!'
        })
    
    except Error as e:
        conn.rollback()
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/attendance/active', methods=['GET'])
def get_active_attendance():
    """Get active (not checked out) attendance for a student"""
    student_id = request.args.get('student_id')
    
    if not student_id:
        return json_response({'error': 'student_id parameter required'}, 400)
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT a.*, s.title as subject_title, s.location_name,
                   s.geofence_center_lat, s.geofence_center_lng, s.geofence_radius_meters
            FROM attendance a
            JOIN subjects s ON a.subject_id = s.subject_id
            WHERE a.student_id = %s AND a.is_checked_out = FALSE
            ORDER BY a.check_in_time DESC
        """, (student_id,))
        
        active = cursor.fetchall()
        
        # Convert Decimal to float
        for record in active:
            record['check_in_lat'] = float(record['check_in_lat'])
            record['check_in_lng'] = float(record['check_in_lng'])
            record['geofence_center_lat'] = float(record['geofence_center_lat'])
            record['geofence_center_lng'] = float(record['geofence_center_lng'])
        
        return json_response({
            'success': True,
            'active_attendance': active
        })
    
    except Error as e:
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/attendance/statistics', methods=['GET'])
def get_attendance_statistics():
    """Get attendance statistics for a student"""
    student_id = request.args.get('student_id')
    
    if not student_id:
        return json_response({'error': 'student_id is required'}, 400)
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        # Get total counts by attendance status
        cursor.execute("""
            SELECT 
                COUNT(*) as total_records,
                SUM(CASE WHEN attendance_status = 'present' THEN 1 ELSE 0 END) as present_count,
                SUM(CASE WHEN attendance_status = 'late' THEN 1 ELSE 0 END) as late_count,
                SUM(CASE WHEN attendance_status = 'absent' THEN 1 ELSE 0 END) as absent_count,
                SUM(CASE WHEN early_checkout_reason IS NOT NULL AND early_checkout_reason != '' THEN 1 ELSE 0 END) as early_checkout_count,
                SUM(CASE WHEN warning_out_of_radius = TRUE THEN 1 ELSE 0 END) as geofence_violations
            FROM attendance
            WHERE student_id = %s
        """, (student_id,))
        
        stats = cursor.fetchone()
        
        # Get recent attendance records (last 5)
        cursor.execute("""
            SELECT a.attendance_status, a.check_in_time, s.title as subject_title,
                   a.early_checkout_reason, a.warning_out_of_radius
            FROM attendance a
            JOIN subjects s ON a.subject_id = s.subject_id
            WHERE a.student_id = %s
            ORDER BY a.check_in_time DESC
            LIMIT 5
        """, (student_id,))
        
        recent_records = cursor.fetchall()
        
        return json_response({
            'statistics': {
                'total': stats['total_records'] or 0,
                'present': stats['present_count'] or 0,
                'late': stats['late_count'] or 0,
                'absent': stats['absent_count'] or 0,
                'early_checkout': stats['early_checkout_count'] or 0,
                'geofence_violations': stats['geofence_violations'] or 0
            },
            'recent_records': recent_records
        })
    
    except Error as e:
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/attendance/history', methods=['GET'])
def get_attendance_history():
    """Get attendance history with filters"""
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        # Build query with filters
        query = """
            SELECT a.*, st.full_name, st.program_or_grade, 
                   s.title as subject_title, s.instructor, s.location_name
            FROM attendance a
            JOIN students st ON a.student_id = st.student_id
            JOIN subjects s ON a.subject_id = s.subject_id
            WHERE 1=1
        """
        params = []
        
        # Apply filters
        if request.args.get('student_id'):
            query += " AND a.student_id = %s"
            params.append(request.args.get('student_id'))
        
        if request.args.get('subject_id'):
            query += " AND a.subject_id = %s"
            params.append(request.args.get('subject_id'))
        
        if request.args.get('date_from'):
            query += " AND DATE(a.check_in_time) >= %s"
            params.append(request.args.get('date_from'))
        
        if request.args.get('date_to'):
            query += " AND DATE(a.check_in_time) <= %s"
            params.append(request.args.get('date_to'))
        
        query += " ORDER BY a.check_in_time DESC LIMIT 1000"
        
        cursor.execute(query, params)
        records = cursor.fetchall()
        
        # Convert Decimal to float
        for record in records:
            record['check_in_lat'] = float(record['check_in_lat'])
            record['check_in_lng'] = float(record['check_in_lng'])
            if record['check_out_lat']:
                record['check_out_lat'] = float(record['check_out_lat'])
                record['check_out_lng'] = float(record['check_out_lng'])
        
        return json_response({
            'success': True,
            'records': records,
            'count': len(records)
        })
    
    except Error as e:
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/attendance/<attendance_id>/tracking', methods=['GET'])
def get_location_tracking(attendance_id):
    """Get all location tracking points for an attendance record"""
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT * FROM location_tracking
            WHERE attendance_id = %s
            ORDER BY recorded_at ASC
        """, (attendance_id,))
        
        tracking = cursor.fetchall()
        
        # Convert Decimal to float
        for point in tracking:
            point['lat'] = float(point['lat'])
            point['lng'] = float(point['lng'])
            if point['distance_from_center']:
                point['distance_from_center'] = float(point['distance_from_center'])
        
        return json_response({
            'success': True,
            'tracking_points': tracking
        })
    
    except Error as e:
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/attendance/<attendance_id>/violations', methods=['GET'])
def get_violations(attendance_id):
    """Get geofence violations for an attendance record"""
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("""
            SELECT * FROM geofence_violations
            WHERE attendance_id = %s
            ORDER BY violation_time ASC
        """, (attendance_id,))
        
        violations = cursor.fetchall()
        
        # Convert Decimal to float
        for violation in violations:
            violation['violation_lat'] = float(violation['violation_lat'])
            violation['violation_lng'] = float(violation['violation_lng'])
            violation['distance_from_center'] = float(violation['distance_from_center'])
        
        return json_response({
            'success': True,
            'violations': violations,
            'count': len(violations)
        })
    
    except Error as e:
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


# ==================== ADMIN DASHBOARD ENDPOINTS ====================

@app.route('/api/admin/stats', methods=['GET'])
def get_admin_stats():
    """Get comprehensive dashboard statistics with attendance analytics"""
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        # Total students
        cursor.execute("SELECT COUNT(*) as count FROM students")
        total_students = cursor.fetchone()['count']
        
        # Total subjects
        cursor.execute("SELECT COUNT(*) as count FROM subjects")
        total_subjects = cursor.fetchone()['count']
        
        # Total attendance records
        cursor.execute("SELECT COUNT(*) as count FROM attendance")
        total_attendance = cursor.fetchone()['count']
        
        # Currently checked in
        cursor.execute("SELECT COUNT(*) as count FROM attendance WHERE is_checked_out = FALSE")
        currently_checked_in = cursor.fetchone()['count']
        
        # Violations today
        cursor.execute("""
            SELECT COUNT(*) as count FROM geofence_violations
            WHERE DATE(violation_time) = CURDATE()
        """)
        violations_today = cursor.fetchone()['count']
        
        # Attendance today
        cursor.execute("""
            SELECT COUNT(*) as count FROM attendance
            WHERE DATE(check_in_time) = CURDATE()
        """)
        attendance_today = cursor.fetchone()['count']
        
        # Attendance status breakdown for today
        cursor.execute("""
            SELECT 
                attendance_status,
                COUNT(*) as count
            FROM attendance
            WHERE DATE(check_in_time) = CURDATE()
            GROUP BY attendance_status
        """)
        status_breakdown = cursor.fetchall()
        
        # Convert to dictionary
        status_counts = {
            'present': 0,
            'late': 0,
            'absent': 0,
            'early_checkout': 0
        }
        for row in status_breakdown:
            if row['attendance_status'] in status_counts:
                status_counts[row['attendance_status']] = row['count']
        
        # Weekly attendance trend (last 7 days)
        cursor.execute("""
            SELECT 
                DATE(check_in_time) as date,
                COUNT(*) as total,
                SUM(CASE WHEN attendance_status = 'present' THEN 1 ELSE 0 END) as present,
                SUM(CASE WHEN attendance_status = 'late' THEN 1 ELSE 0 END) as late,
                SUM(CASE WHEN attendance_status = 'early_checkout' THEN 1 ELSE 0 END) as early_checkout
            FROM attendance
            WHERE check_in_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            GROUP BY DATE(check_in_time)
            ORDER BY date DESC
        """)
        weekly_trend = cursor.fetchall()
        
        # Active students with real-time location status
        cursor.execute("""
            SELECT 
                a.attendance_id,
                a.student_id,
                s.full_name,
                s.program_or_grade,
                a.subject_id,
                subj.title as subject_title,
                subj.scheduled_start,
                subj.scheduled_end,
                a.check_in_time,
                a.attendance_status,
                a.warning_out_of_radius,
                (SELECT is_within_geofence 
                 FROM location_tracking 
                 WHERE attendance_id = a.attendance_id 
                 ORDER BY recorded_at DESC LIMIT 1) as current_location_status
            FROM attendance a
            JOIN students s ON a.student_id = s.student_id
            JOIN subjects subj ON a.subject_id = subj.subject_id
            WHERE a.is_checked_out = FALSE
            ORDER BY a.check_in_time DESC
        """)
        active_students = cursor.fetchall()
        
        # Serialize the results
        for record in weekly_trend:
            record = serialize_record(record)
        for record in active_students:
            record = serialize_record(record)
        
        return json_response({
            'success': True,
            'stats': {
                'total_students': total_students,
                'total_subjects': total_subjects,
                'total_attendance': total_attendance,
                'currently_checked_in': currently_checked_in,
                'violations_today': violations_today,
                'attendance_today': attendance_today,
                'status_breakdown_today': status_counts,
                'weekly_trend': weekly_trend,
                'active_students': active_students
            }
        })
    
    except Error as e:
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/admin/export-csv', methods=['GET'])
def export_csv():
    """Export attendance records as CSV"""
    import csv
    from io import StringIO
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        
        # Build query with filters
        query = """
            SELECT a.attendance_id, a.student_id, st.full_name, st.program_or_grade,
                   a.subject_id, s.title as subject_title, s.instructor, s.location_name,
                   a.check_in_time, a.check_in_lat, a.check_in_lng, a.check_in_status,
                   a.check_out_time, a.check_out_lat, a.check_out_lng, a.check_out_status,
                   a.warning_out_of_radius
            FROM attendance a
            JOIN students st ON a.student_id = st.student_id
            JOIN subjects s ON a.subject_id = s.subject_id
            WHERE 1=1
        """
        params = []
        
        if request.args.get('date_from'):
            query += " AND DATE(a.check_in_time) >= %s"
            params.append(request.args.get('date_from'))
        
        if request.args.get('date_to'):
            query += " AND DATE(a.check_in_time) <= %s"
            params.append(request.args.get('date_to'))
        
        query += " ORDER BY a.check_in_time DESC"
        
        cursor.execute(query, params)
        records = cursor.fetchall()
        
        # Create CSV
        output = StringIO()
        if records:
            writer = csv.DictWriter(output, fieldnames=records[0].keys())
            writer.writeheader()
            writer.writerows(records)
        
        csv_data = output.getvalue()
        
        return json_response({
            'success': True,
            'csv_data': csv_data,
            'record_count': len(records)
        })
    
    except Error as e:
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


# ==================== ENROLLMENT ENDPOINTS ====================

@app.route('/api/enrollments', methods=['GET'])
def get_enrollments():
    """Get enrollments - all, by student, or by subject"""
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor(dictionary=True)
        student_id = request.args.get('student_id')
        subject_id = request.args.get('subject_id')
        
        if student_id:
            # Get subjects enrolled by a specific student
            query = """
                SELECT e.*, s.title, s.instructor, s.location_name,
                       s.scheduled_start, s.scheduled_end, s.scheduled_days,
                       s.geofence_center_lat, s.geofence_center_lng, s.geofence_radius_meters
                FROM student_enrollments e
                JOIN subjects s ON e.subject_id = s.subject_id
                WHERE e.student_id = %s AND e.status = 'active'
                ORDER BY s.scheduled_start
            """
            cursor.execute(query, (student_id,))
        elif subject_id:
            # Get students enrolled in a specific subject
            query = """
                SELECT e.*, st.full_name, st.program_or_grade, st.email, st.phone
                FROM student_enrollments e
                JOIN students st ON e.student_id = st.student_id
                WHERE e.subject_id = %s AND e.status = 'active'
                ORDER BY st.full_name
            """
            cursor.execute(query, (subject_id,))
        else:
            # Get all enrollments
            query = """
                SELECT e.*, st.full_name, s.title as subject_title
                FROM student_enrollments e
                JOIN students st ON e.student_id = st.student_id
                JOIN subjects s ON e.subject_id = s.subject_id
                WHERE e.status = 'active'
                ORDER BY e.enrolled_at DESC
            """
            cursor.execute(query)
        
        enrollments = cursor.fetchall()
        enrollments = [serialize_record(e) for e in enrollments]
        
        return json_response({
            'success': True,
            'enrollments': enrollments,
            'count': len(enrollments)
        })
    
    except Error as e:
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/enrollments', methods=['POST'])
def create_enrollment():
    """Enroll a student in a subject"""
    data = request.get_json()
    
    # Validate required fields
    valid, error = validate_required_fields(data, ['student_id', 'subject_id'])
    if not valid:
        return json_response({'error': error}, 400)
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor()
        
        # Check if student exists
        cursor.execute("SELECT id FROM students WHERE student_id = %s", (data['student_id'],))
        if not cursor.fetchone():
            return json_response({'error': 'Student not found'}, 404)
        
        # Check if subject exists
        cursor.execute("SELECT id FROM subjects WHERE subject_id = %s", (data['subject_id'],))
        if not cursor.fetchone():
            return json_response({'error': 'Subject not found'}, 404)
        
        # Check if already enrolled
        cursor.execute("""
            SELECT id FROM student_enrollments 
            WHERE student_id = %s AND subject_id = %s AND status = 'active'
        """, (data['student_id'], data['subject_id']))
        
        if cursor.fetchone():
            return json_response({'error': 'Student is already enrolled in this subject'}, 409)
        
        # Create enrollment
        query = """
            INSERT INTO student_enrollments (student_id, subject_id, enrolled_by, status)
            VALUES (%s, %s, %s, 'active')
        """
        cursor.execute(query, (
            data['student_id'],
            data['subject_id'],
            data.get('enrolled_by', 'admin')
        ))
        conn.commit()
        
        return json_response({
            'success': True,
            'message': 'Student enrolled successfully'
        }, 201)
    
    except Error as e:
        conn.rollback()
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/enrollments/<int:enrollment_id>', methods=['DELETE'])
def delete_enrollment(enrollment_id):
    """Remove a student from a subject (unenroll)"""
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor()
        
        # Update status to 'dropped' instead of deleting
        cursor.execute("""
            UPDATE student_enrollments 
            SET status = 'dropped'
            WHERE id = %s
        """, (enrollment_id,))
        
        conn.commit()
        
        if cursor.rowcount == 0:
            return json_response({'error': 'Enrollment not found'}, 404)
        
        return json_response({
            'success': True,
            'message': 'Student unenrolled successfully'
        })
    
    except Error as e:
        conn.rollback()
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


@app.route('/api/enrollments/bulk', methods=['POST'])
def bulk_enroll():
    """Enroll multiple students in a subject or one student in multiple subjects"""
    data = request.get_json()
    
    student_ids = data.get('student_ids', [])
    subject_ids = data.get('subject_ids', [])
    
    if not student_ids or not subject_ids:
        return json_response({'error': 'student_ids and subject_ids are required'}, 400)
    
    conn = get_db_connection()
    if not conn:
        return json_response({'error': 'Database connection failed'}, 500)
    
    try:
        cursor = conn.cursor()
        enrolled_count = 0
        skipped_count = 0
        
        for student_id in student_ids:
            for subject_id in subject_ids:
                # Check if already enrolled
                cursor.execute("""
                    SELECT id FROM student_enrollments 
                    WHERE student_id = %s AND subject_id = %s AND status = 'active'
                """, (student_id, subject_id))
                
                if cursor.fetchone():
                    skipped_count += 1
                    continue
                
                # Enroll
                cursor.execute("""
                    INSERT INTO student_enrollments (student_id, subject_id, enrolled_by, status)
                    VALUES (%s, %s, %s, 'active')
                """, (student_id, subject_id, data.get('enrolled_by', 'admin')))
                enrolled_count += 1
        
        conn.commit()
        
        return json_response({
            'success': True,
            'message': f'Enrolled {enrolled_count} student-subject pairs',
            'enrolled': enrolled_count,
            'skipped': skipped_count
        }, 201)
    
    except Error as e:
        conn.rollback()
        return json_response({'error': f'Database error: {str(e)}'}, 500)
    finally:
        cursor.close()
        conn.close()


# ==================== HEALTH CHECK ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    conn = get_db_connection()
    if conn:
        conn.close()
        return json_response({
            'status': 'healthy',
            'database': 'connected',
            'tracking_interval': TRACKING_INTERVAL_SECONDS
        })
    else:
        return json_response({
            'status': 'unhealthy',
            'database': 'disconnected'
        }, 503)


@app.route('/api/test-time', methods=['GET'])
def test_time():
    """Test endpoint to verify timezone configuration"""
    current = get_current_time()
    return json_response({
        'current_time': current.strftime('%Y-%m-%d %I:%M:%S %p'),
        'timezone': 'Asia/Manila (Philippine Time)',
        'iso_format': current.isoformat(),
        'timestamp': current.timestamp() if hasattr(current, 'timestamp') else str(current)
    })


@app.route('/', methods=['GET'])
def index():
    """API information"""
    return json_response({
        'name': 'GPS Attendance Tracking API',
        'version': '1.0.0',
        'timezone': 'Asia/Manila (Philippine Time)',
        'endpoints': {
            'students': '/api/students',
            'subjects': '/api/subjects',
            'attendance': '/api/attendance/*',
            'admin': '/api/admin/*',
            'health': '/api/health',
            'test-time': '/api/test-time'
        }
    })


if __name__ == '__main__':
    # Run the Flask app
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('DEBUG', 'True').lower() == 'true'
    
    print(f"Starting GPS Attendance API on port {port}...")
    print(f"Database: {DB_CONFIG['database']}@{DB_CONFIG['host']}")
    print(f"Tracking interval: {TRACKING_INTERVAL_SECONDS} seconds")
    
    app.run(host='0.0.0.0', port=port, debug=debug)
