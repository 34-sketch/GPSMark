"""
Test database connection for GPS Attendance System
"""
import mysql.connector
from mysql.connector import Error
import os

# Database configuration (same as app.py)
DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'user': os.getenv('DB_USER', 'root'),
    'password': os.getenv('DB_PASSWORD', ''),
    'database': os.getenv('DB_NAME', 'gps_attendance'),
    'charset': 'utf8mb4',
    'collation': 'utf8mb4_unicode_ci'
}

def test_connection():
    """Test database connection"""
    print("=" * 60)
    print("DATABASE CONNECTION TEST")
    print("=" * 60)
    print(f"\nConfiguration:")
    print(f"  Host: {DB_CONFIG['host']}")
    print(f"  User: {DB_CONFIG['user']}")
    print(f"  Database: {DB_CONFIG['database']}")
    print(f"  Password: {'(empty)' if not DB_CONFIG['password'] else '(set)'}")
    print("\nAttempting connection...")
    
    try:
        # Attempt to connect
        connection = mysql.connector.connect(**DB_CONFIG)
        
        if connection.is_connected():
            db_info = connection.get_server_info()
            cursor = connection.cursor()
            cursor.execute("SELECT DATABASE();")
            db_name = cursor.fetchone()[0]
            
            print("\n[SUCCESS] Database connection established.")
            print(f"  MySQL Server version: {db_info}")
            print(f"  Connected to database: {db_name}")
            
            # Test table existence
            print("\nChecking tables...")
            cursor.execute("SHOW TABLES;")
            tables = cursor.fetchall()
            
            if tables:
                print(f"  Found {len(tables)} tables:")
                for table in tables:
                    cursor.execute(f"SELECT COUNT(*) FROM {table[0]};")
                    count = cursor.fetchone()[0]
                    print(f"    - {table[0]}: {count} records")
            else:
                print("  [WARNING] No tables found in database")
            
            cursor.close()
            connection.close()
            print("\n" + "=" * 60)
            print("Connection test completed successfully!")
            print("=" * 60)
            return True
            
    except Error as e:
        print(f"\n[ERROR] Database connection failed!")
        print(f"  Error: {e}")
        print("\nPossible solutions:")
        print("  1. Make sure XAMPP MySQL is running")
        print("  2. Check if database 'gps_attendance' exists")
        print("  3. Verify MySQL credentials")
        print("  4. Check if MySQL is listening on localhost:3306")
        print("\n" + "=" * 60)
        return False

if __name__ == "__main__":
    test_connection()
