"""Test script to verify Philippine timezone is working correctly"""
from datetime import datetime
import pytz

# Philippine timezone
TIMEZONE = pytz.timezone('Asia/Manila')

def get_current_time():
    """Get current time in Philippine timezone (naive datetime for MySQL compatibility)"""
    return datetime.now(TIMEZONE).replace(tzinfo=None)

# Test the function
current_time = get_current_time()
print(f"Current Philippine Time: {current_time}")
print(f"Formatted: {current_time.strftime('%Y-%m-%d %I:%M:%S %p')}")
print(f"Time only: {current_time.strftime('%I:%M %p')}")
print(f"Expected: Around 7:36 PM on October 10, 2025")
