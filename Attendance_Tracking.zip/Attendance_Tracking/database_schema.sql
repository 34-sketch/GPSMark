-- GPS Attendance Tracking System Database Schema
-- MySQL/MariaDB compatible
-- Complete schema with all tables and sample data
-- Import this file to set up the entire database

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS gps_attendance;
USE gps_attendance;

-- Students table
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    program_or_grade VARCHAR(100),
    email VARCHAR(255),
    phone VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_student_id (student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Subjects/Classes table
CREATE TABLE IF NOT EXISTS subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject_id VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    instructor VARCHAR(255),
    location_name VARCHAR(255),
    scheduled_start TIME,
    scheduled_end TIME,
    scheduled_days VARCHAR(50) DEFAULT 'Mon,Tue,Wed,Thu,Fri,Sat,Sun',
    geofence_center_lat DECIMAL(10, 8) NOT NULL,
    geofence_center_lng DECIMAL(11, 8) NOT NULL,
    geofence_radius_meters INT NOT NULL DEFAULT 100,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_subject_id (subject_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Student-Subject Enrollment table (which subjects each student is enrolled in)
CREATE TABLE IF NOT EXISTS student_enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50) NOT NULL,
    subject_id VARCHAR(50) NOT NULL,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    enrolled_by VARCHAR(100) DEFAULT 'admin',
    status ENUM('active', 'dropped', 'completed') DEFAULT 'active',
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    UNIQUE KEY unique_enrollment (student_id, subject_id),
    INDEX idx_student_id (student_id),
    INDEX idx_subject_id (subject_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Attendance records table
CREATE TABLE IF NOT EXISTS attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    attendance_id VARCHAR(100) UNIQUE NOT NULL,
    student_id VARCHAR(50) NOT NULL,
    subject_id VARCHAR(50) NOT NULL,
    check_in_time DATETIME NOT NULL,
    check_in_lat DECIMAL(10, 8) NOT NULL,
    check_in_lng DECIMAL(11, 8) NOT NULL,
    check_in_status ENUM('valid', 'out_of_range', 'warning') DEFAULT 'valid',
    check_out_time DATETIME,
    check_out_lat DECIMAL(10, 8),
    check_out_lng DECIMAL(11, 8),
    check_out_status ENUM('valid', 'out_of_range', 'warning'),
    is_checked_out BOOLEAN DEFAULT FALSE,
    warning_out_of_radius BOOLEAN DEFAULT FALSE,
    attendance_status ENUM('present', 'late', 'absent', 'early_checkout') DEFAULT 'present',
    early_checkout_reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    INDEX idx_attendance_id (attendance_id),
    INDEX idx_student_subject (student_id, subject_id),
    INDEX idx_check_in_time (check_in_time),
    INDEX idx_attendance_status (attendance_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Location tracking table (stores periodic location updates while checked-in)
CREATE TABLE IF NOT EXISTS location_tracking (
    id INT AUTO_INCREMENT PRIMARY KEY,
    attendance_id VARCHAR(100) NOT NULL,
    lat DECIMAL(10, 8) NOT NULL,
    lng DECIMAL(11, 8) NOT NULL,
    is_within_geofence BOOLEAN DEFAULT TRUE,
    distance_from_center DECIMAL(10, 2),
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (attendance_id) REFERENCES attendance(attendance_id) ON DELETE CASCADE,
    INDEX idx_attendance_id (attendance_id),
    INDEX idx_recorded_at (recorded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Geofence violation events table
CREATE TABLE IF NOT EXISTS geofence_violations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    attendance_id VARCHAR(100) NOT NULL,
    student_id VARCHAR(50) NOT NULL,
    subject_id VARCHAR(50) NOT NULL,
    violation_lat DECIMAL(10, 8) NOT NULL,
    violation_lng DECIMAL(11, 8) NOT NULL,
    distance_from_center DECIMAL(10, 2) NOT NULL,
    violation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (attendance_id) REFERENCES attendance(attendance_id) ON DELETE CASCADE,
    INDEX idx_attendance_id (attendance_id),
    INDEX idx_violation_time (violation_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample data for testing
INSERT INTO students (student_id, full_name, program_or_grade, email, phone) VALUES
('STU001', 'John Doe', 'Grade 10', 'john.doe@example.com', '555-0101'),
('STU002', 'Jane Smith', 'Computer Science', 'jane.smith@example.com', '555-0102'),
('STU003', 'Mike Johnson', 'Grade 11', 'mike.j@example.com', '555-0103');

INSERT INTO subjects (subject_id, title, instructor, location_name, scheduled_start, scheduled_end, scheduled_days, geofence_center_lat, geofence_center_lng, geofence_radius_meters) VALUES
('SUBJ001', 'Mathematics 101', 'Prof. Anderson', 'Room 201', '08:00:00', '09:30:00', 'Mon,Wed,Fri', 14.5995, 120.9842, 50),
('SUBJ002', 'Computer Science', 'Dr. Williams', 'Lab Building A', '10:00:00', '12:00:00', 'Tue,Thu', 14.6000, 120.9850, 75),
('SUBJ003', 'Physics Lab', 'Prof. Brown', 'Science Building', '14:00:00', '16:00:00', 'Mon,Tue,Wed,Thu,Fri', 14.5990, 120.9845, 60);

-- Sample enrollments (students enrolled in specific subjects)
INSERT INTO student_enrollments (student_id, subject_id, status) VALUES
('STU001', 'SUBJ001', 'active'),  -- John Doe enrolled in Mathematics
('STU001', 'SUBJ003', 'active'),  -- John Doe enrolled in Physics
('STU002', 'SUBJ002', 'active'),  -- Jane Smith enrolled in Computer Science
('STU002', 'SUBJ001', 'active'),  -- Jane Smith enrolled in Mathematics
('STU003', 'SUBJ003', 'active');  -- Mike Johnson enrolled in Physics
