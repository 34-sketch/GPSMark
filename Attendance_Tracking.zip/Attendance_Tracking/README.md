# GPS Attendance Tracking System

A comprehensive GPS-based attendance tracking system with real-time geofence validation, featuring a PHP frontend and Python Flask backend.

## Quick Start

1. **Import Database**: Import `database_schema.sql` into MySQL via phpMyAdmin
2. **Configure Backend**: Copy `backend/.env.example` to `backend/.env` and update credentials
3. **Install Dependencies**: Run `pip install -r backend/requirements.txt`
4. **Start Backend**: Run `python backend/app.py`
5. **Access Application**: Visit `http://localhost/Attendance_Tracking/frontend/login.php`

## Features

### Core Functionality
- **Student Registration** - Create student accounts with unique IDs
- **Subject/Class Management** - Define classes with geofence boundaries
- **GPS Check-In/Out** - Real-time location-based attendance tracking
- **Geofence Validation** - Automatic validation of student location within defined radius
- **Real-Time Tracking** - Continuous location monitoring while checked in (configurable interval)
- **Violation Detection** - Automatic detection and logging when students leave geofence area
- **Admin Dashboard** - Comprehensive analytics and reporting
- **Map Visualization** - Interactive maps showing attendance locations and tracking paths
- **CSV Export** - Export attendance records for external analysis

### Security Features
- Input validation on all endpoints
- SQL injection protection via parameterized queries
- CORS configuration for API security
- Session management for user authentication

## Technology Stack

### Backend
- **Python 3.8+** with Flask
- **MySQL/MariaDB** database
- **Flask-CORS** for cross-origin requests
- **mysql-connector-python** for database connectivity

### Frontend
- **PHP 7.4+** for server-side rendering
- **Tailwind CSS** for modern UI styling
- **Leaflet.js** for interactive maps
- **Font Awesome** for icons
- **Vanilla JavaScript** for GPS tracking

### Location Tracking API
- **HTML5 Geolocation API** (`navigator.geolocation`)
  - `getCurrentPosition()` - For check-in/check-out location capture
  - `watchPosition()` - For continuous real-time location tracking
  - High accuracy mode enabled for GPS-level precision
  - No external dependencies or API keys required

## Project Structure

```
Attendance_Tracking/
├── backend/
│   ├── app.py                 # Main Flask application
│   ├── requirements.txt       # Python dependencies
│   └── .env.example          # Environment configuration template
├── frontend/
│   ├── config.php            # PHP configuration
│   ├── login.php             # Student login
│   ├── register.php          # Student registration
│   ├── dashboard.php         # Student dashboard with check-in/out
│   ├── history.php           # Student attendance history
│   ├── logout.php            # Logout handler
│   ├── admin/
│   │   ├── index.php         # Admin dashboard
│   │   ├── students.php      # Student management
│   │   ├── subjects.php      # Subject management
│   │   └── reports.php       # Reports and analytics
│   └── js/
│       └── gps-tracker.js    # GPS tracking module
├── database_schema.sql       # Database schema and sample data
└── README.md                 # This file
```

## Installation & Setup

### Prerequisites
- **XAMPP** (or similar LAMP/WAMP stack)
  - Apache web server
  - MySQL/MariaDB
  - PHP 7.4 or higher
- **Python 3.8+**
- **pip** (Python package manager)

### Step 1: Database Setup

1. Start XAMPP and ensure MySQL is running
2. Open phpMyAdmin (http://localhost/phpmyadmin)
3. Import the complete database schema:
   - Click "Import" tab
   - Choose file: `database_schema.sql`
   - Click "Go"
   
   **Note**: The schema file will automatically create the `gps_attendance` database and all tables with sample data.
   
   Alternatively, via command line:
   ```bash
   mysql -u root -p < database_schema.sql
   ```

### Step 2: Python Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Create environment configuration:
   ```bash
   copy .env.example .env
   ```

4. Edit `.env` file with your database credentials:
   ```env
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=your_password
   DB_NAME=gps_attendance
   PORT=5000
   DEBUG=True
   TRACKING_INTERVAL=10
   ```

5. Start the Flask backend:
   ```bash
   python app.py
   ```
   
   The API will be available at: `http://localhost:5000`

### Step 3: PHP Frontend Setup

1. Ensure the project is in your XAMPP htdocs directory:
   ```
   C:\xampp\htdocs\Attendance_Tracking\
   ```

2. Edit `frontend/config.php` if needed (default settings should work):
   ```php
   define('API_BASE_URL', 'http://localhost:5000/api');
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASSWORD', '');
   define('DB_NAME', 'gps_attendance');
   ```

3. Access the application:
   - **Student Portal**: http://localhost/Attendance_Tracking/frontend/login.php
   - **Admin Dashboard**: http://localhost/Attendance_Tracking/frontend/admin/index.php

### Step 4: Testing

1. **Register a Student**:
   - Go to: http://localhost/Attendance_Tracking/frontend/register.php
   - Use sample data or create your own

2. **Login**:
   - Use the Student ID you created
   - You'll be redirected to the dashboard

3. **Test Check-In**:
   - Allow browser location access when prompted
   - Click "Check In" on any subject
   - System will validate your location against the geofence

## Configuration

### Tracking Interval
Adjust the GPS tracking frequency in `backend/.env`:
```env
TRACKING_INTERVAL=10  # seconds (default: 10)
```

Also update in `frontend/config.php`:
```php
define('TRACKING_INTERVAL_MS', 10000); // milliseconds
```

### Geofence Settings
- Default radius: 50 meters (configurable per subject)
- Location accuracy: High accuracy mode enabled
- Violation threshold: Immediate detection when outside radius

### Map Configuration
Default map center in `frontend/config.php`:
```php
define('DEFAULT_MAP_CENTER_LAT', 14.5995);
define('DEFAULT_MAP_CENTER_LNG', 120.9842);
define('DEFAULT_MAP_ZOOM', 15);
```

## API Endpoints

### Students
- `GET /api/students` - Get all students
- `GET /api/students?student_id={id}` - Get specific student
- `POST /api/students` - Register new student
- `PUT /api/students/{student_id}` - Update student

### Subjects
- `GET /api/subjects` - Get all subjects
- `GET /api/subjects?subject_id={id}` - Get specific subject
- `POST /api/subjects` - Create new subject

### Attendance
- `POST /api/attendance/check-in` - Check in to a subject
- `POST /api/attendance/check-out` - Check out from attendance
- `POST /api/attendance/track-location` - Send location update
- `GET /api/attendance/active?student_id={id}` - Get active attendance
- `GET /api/attendance/history` - Get attendance history (with filters)
- `GET /api/attendance/{id}/tracking` - Get location tracking points
- `GET /api/attendance/{id}/violations` - Get geofence violations

### Admin
- `GET /api/admin/stats` - Get dashboard statistics
- `GET /api/admin/export-csv` - Export attendance to CSV

### Health
- `GET /api/health` - API health check

## Usage Guide

### For Students

1. **Registration**:
   - Visit the registration page
   - Fill in Student ID, Full Name, and optional details
   - Submit to create account

2. **Login**:
   - Enter your Student ID
   - Access your dashboard

3. **Check In**:
   - View available subjects on dashboard
   - Ensure you're at the class location
   - Allow browser location access
   - Click "Check In" button
   - System validates your location against geofence
   - If valid, tracking starts automatically

4. **During Class**:
   - GPS tracking runs in background (every 10 seconds)
   - Stay within geofence radius
   - Warning appears if you leave the area
   - Violations are logged automatically

5. **Check Out**:
   - Click "Check Out" button when class ends
   - System records final location
   - Tracking stops

6. **View History**:
   - Click "History" in navigation
   - View all attendance records
   - Click "View Map" to see tracking path

### For Administrators

1. **Dashboard**:
   - View real-time statistics
   - Monitor currently checked-in students
   - See recent attendance and violations

2. **Student Management**:
   - Add new students
   - View all registered students
   - Search and filter students
   - View individual attendance records

3. **Subject Management**:
   - Create new subjects/classes
   - Set geofence location using interactive map
   - Define geofence radius
   - Set class schedule
   - View subject-specific attendance

4. **Reports & Analytics**:
   - Filter by student, subject, date range
   - View detailed attendance records
   - Export to CSV for external analysis
   - Interactive map showing tracking paths
   - Geofence violation analysis

## Troubleshooting

### Location Not Detected
- Ensure HTTPS or localhost (required for geolocation API)
- Check browser location permissions
- Verify GPS/location services are enabled on device

### API Connection Failed
- Verify Flask backend is running on port 5000
- Check `API_BASE_URL` in `frontend/config.php`
- Ensure no firewall blocking port 5000

### Database Connection Error
- Verify MySQL is running in XAMPP
- Check database credentials in `.env` and `config.php`
- Ensure `gps_attendance` database exists

### Geofence Not Working
- Verify subject has valid coordinates
- Check geofence radius is reasonable (50-100m recommended)
- Ensure location accuracy is sufficient

### CORS Errors
- Backend must be running with Flask-CORS enabled
- Check browser console for specific errors
- Verify API_BASE_URL matches backend address

## Sample Data

The database schema includes sample data:

**Students**:
- STU001 - John Doe (Grade 10)
- STU002 - Jane Smith (Computer Science)
- STU003 - Mike Johnson (Grade 11)

**Subjects**:
- SUBJ001 - Mathematics 101 (Room 201, 50m radius)
- SUBJ002 - Computer Science (Lab Building A, 75m radius)
- SUBJ003 - Physics Lab (Science Building, 60m radius)

## Security Considerations

1. **Production Deployment**:
   - Change default database passwords
   - Disable DEBUG mode in Flask
   - Use HTTPS for all connections
   - Implement proper authentication
   - Add rate limiting to API endpoints

2. **Data Privacy**:
   - Location data is sensitive
   - Implement data retention policies
   - Add user consent mechanisms
   - Consider GDPR/privacy regulations

3. **API Security**:
   - Add API authentication (JWT tokens)
   - Implement request validation
   - Add rate limiting
   - Use prepared statements (already implemented)

## Performance Optimization

1. **Database**:
   - Indexes already added on key columns
   - Consider partitioning for large datasets
   - Regular cleanup of old tracking data

2. **Tracking**:
   - Adjust TRACKING_INTERVAL based on needs
   - Consider battery impact on mobile devices
   - Implement smart tracking (only when needed)

3. **Frontend**:
   - Cache static resources
   - Minimize API calls
   - Use pagination for large datasets

## Future Enhancements

- [ ] Mobile app (React Native/Flutter)
- [ ] Push notifications for violations
- [ ] QR code check-in as backup
- [ ] Facial recognition integration
- [ ] Advanced analytics and reporting
- [ ] Multi-language support
- [ ] Email notifications
- [ ] Attendance reports generation
- [ ] Integration with LMS systems
- [ ] Offline mode support

## License

This project is provided as-is for educational and commercial use.

## Support

For issues, questions, or contributions:
1. Check the troubleshooting section
2. Review API documentation
3. Check browser console for errors
4. Verify all services are running

## Credits

- **Leaflet.js** - Interactive maps
- **Tailwind CSS** - UI framework
- **Font Awesome** - Icons
- **OpenStreetMap** - Map tiles
- **Flask** - Python web framework

---

**Version**: 1.0.0  
**Last Updated**: October 2025  
**Developed for**: GPS-based attendance tracking with real-time geofence validation
